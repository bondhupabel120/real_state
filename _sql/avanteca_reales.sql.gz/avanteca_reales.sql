-- MySQL dump 10.18  Distrib 10.3.27-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: avanteca_reales
-- ------------------------------------------------------
-- Server version	10.3.27-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `p_id` bigint(20) unsigned DEFAULT NULL,
  `featured` double DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categories_user_id_foreign` (`user_id`),
  CONSTRAINT `categories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`id`, `name`, `slug`, `type`, `p_id`, `featured`, `user_id`, `status`, `created_at`, `updated_at`) VALUES (1,'Apartment','apartment','category',NULL,1,1,1,'2020-12-31 13:07:41','2020-12-31 13:10:27'),(2,'Villa','villa','category',NULL,1,1,1,'2020-12-31 13:08:00','2020-12-31 13:10:18'),(3,'House','house','category',NULL,1,1,1,'2020-12-31 13:08:14','2020-12-31 13:10:07'),(4,'Condo','condo','category',NULL,1,1,1,'2020-12-31 13:08:30','2020-12-31 13:09:58'),(5,'Land','land','category',NULL,1,1,1,'2020-12-31 13:08:49','2020-12-31 13:09:49'),(6,'Commercial Property','commercial-property','category',NULL,1,1,1,'2020-12-31 13:09:13','2020-12-31 13:09:32'),(14,'USD','$','currency',NULL,1,1,1,'2020-12-31 13:16:50','2020-12-31 13:16:50'),(15,'Number of Blocks','number','option',NULL,1,1,0,'2020-12-31 13:17:53','2021-01-11 09:44:10'),(16,'Bedrooms','number','option',NULL,1,1,0,'2020-12-31 13:19:37','2020-12-31 13:19:37'),(17,'Bathrooms','number','option',NULL,1,1,0,'2020-12-31 13:20:11','2020-12-31 13:20:11'),(18,'Floors','number','option',NULL,1,1,1,'2020-12-31 13:21:03','2021-01-10 23:23:13'),(19,'Dhaka','dhaka','states',NULL,1,1,1,'2020-12-31 13:24:25','2020-12-31 13:24:25'),(20,'Chattogram','chattogram','states',NULL,1,1,1,'2020-12-31 13:25:23','2020-12-31 13:25:23'),(21,'Dhaka','dhaka','cities',19,0,1,1,'2020-12-31 13:27:36','2020-12-31 13:27:36'),(22,'Faridpur','faridpur','cities',19,0,1,1,'2020-12-31 13:28:31','2020-12-31 13:28:31'),(23,'Chattogram','chattogram','cities',20,0,1,1,'2020-12-31 13:29:17','2020-12-31 13:29:17'),(24,'Cox\'s Bazar','coxs-bazar','cities',20,1,1,1,'2020-12-31 13:30:51','2020-12-31 13:30:51'),(26,'Sale','sale','status',NULL,1,1,1,'2021-01-10 13:46:34','2021-01-10 13:46:34'),(27,'Rent','rent','status',NULL,1,1,1,'2021-01-10 13:46:39','2021-01-10 13:46:39'),(29,'Projects','projects','status',NULL,1,1,1,'2021-01-10 18:26:59','2021-01-10 18:26:59'),(30,'Share','share','status',NULL,1,1,1,'2021-01-10 18:28:37','2021-01-10 18:28:37'),(31,'Rajshahi','rajshahi','states',NULL,1,1,1,'2021-01-10 19:56:28','2021-01-10 19:56:28'),(32,'Jessore','jessore','states',NULL,1,1,1,'2021-01-10 19:57:58','2021-01-10 19:57:58'),(33,'Khulna','khulna','states',NULL,1,1,1,'2021-01-10 19:59:05','2021-01-10 19:59:05'),(34,'Sylhet','sylhet','states',NULL,1,1,1,'2021-01-10 20:02:50','2021-01-10 20:02:50'),(35,'Wifi','wifi','feature',NULL,1,1,1,'2021-01-10 22:53:51','2021-01-10 22:53:51'),(36,'Swimming pool','swimming-pool','feature',NULL,0,1,1,'2021-01-10 22:54:12','2021-01-10 22:54:12'),(37,'Parking','parking','feature',NULL,0,1,1,'2021-01-10 22:54:37','2021-01-10 22:54:37'),(38,'Security','security','feature',NULL,0,1,1,'2021-01-10 22:54:57','2021-01-10 22:54:57'),(39,'Fitness center','fitness-center','feature',NULL,0,1,1,'2021-01-10 22:55:39','2021-01-10 22:55:39'),(40,'Balcony','balcony','feature',NULL,0,1,1,'2021-01-10 22:56:00','2021-01-10 22:56:00'),(41,'Hospital','hospital','facilities',NULL,0,1,1,'2021-01-10 23:01:58','2021-01-10 23:01:58'),(42,'Super Market','super-market','facilities',NULL,0,1,1,'2021-01-10 23:02:45','2021-01-10 23:02:45'),(43,'School','school','facilities',NULL,0,1,1,'2021-01-10 23:03:04','2021-01-10 23:03:04'),(44,'Entertainment','entertainment','facilities',NULL,0,1,1,'2021-01-10 23:03:20','2021-01-10 23:03:20'),(45,'Pharmacy','pharmacy','facilities',NULL,0,1,1,'2021-01-10 23:04:00','2021-01-10 23:04:00'),(46,'Airport','airport','facilities',NULL,0,1,1,'2021-01-10 23:04:23','2021-01-10 23:04:23'),(47,'Railways','railways','facilities',NULL,0,1,1,'2021-01-10 23:04:35','2021-01-10 23:04:35'),(48,'Bus Stop','bus-stop','facilities',NULL,0,1,1,'2021-01-10 23:04:50','2021-01-10 23:04:50'),(49,'Beach','beach','facilities',NULL,0,1,1,'2021-01-10 23:05:04','2021-01-10 23:05:04'),(50,'Mall','mall','facilities',NULL,0,1,1,'2021-01-10 23:05:24','2021-01-10 23:05:24'),(51,'Bank','bank','facilities',NULL,0,1,1,'2021-01-10 23:05:40','2021-01-10 23:05:40'),(52,'AMCoders','amcodersrzBcY','agency',NULL,NULL,1,1,'2021-01-11 19:53:20','2021-01-11 20:11:04'),(53,'Fast Box','fast-box','agency',NULL,NULL,1,1,'2021-01-11 20:23:26','2021-01-11 20:28:08'),(54,'Company Slogan','company-slogan','agency',NULL,NULL,1,1,'2021-01-11 20:31:19','2021-01-11 20:31:19'),(61,'jomidar','en','lang',NULL,NULL,1,1,'2021-01-18 14:22:05','2021-01-18 14:22:32'),(62,'jomidar','ar','lang',NULL,NULL,1,1,'2021-01-18 14:22:14','2021-01-18 14:22:32'),(63,'BDT','TK','currency',NULL,84,1,1,'2020-12-31 13:16:50','2020-12-31 13:16:50'),(64,'Paypal','uploads/paypal.png','getway',NULL,0,1,1,'2021-06-09 00:19:34','2021-06-09 00:19:34'),(65,'stripe','uploads/stripe.png','getway',NULL,0,1,1,'2021-06-09 00:19:34','2021-06-09 00:19:34'),(66,'toyyibpay','uploads/toyyibpay.png','getway',NULL,0,1,1,'2021-06-09 00:19:34','2021-06-09 00:19:34'),(67,'Razorpay','uploads/razorpay.png','getway',NULL,0,1,1,'2021-06-09 00:19:34','2021-06-09 00:19:34'),(68,'Instamojo','uploads/instamojo.png','getway',NULL,0,1,1,'2021-06-09 00:19:34','2021-06-09 00:19:34'),(69,'Mollie','uploads/mollie.png','getway',NULL,0,1,1,'2021-06-09 00:19:34','2021-06-09 00:19:34');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorymetas`
--

DROP TABLE IF EXISTS `categorymetas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorymetas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint(20) unsigned NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categorymetas_category_id_foreign` (`category_id`),
  CONSTRAINT `categorymetas_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorymetas`
--

LOCK TABLES `categorymetas` WRITE;
/*!40000 ALTER TABLE `categorymetas` DISABLE KEYS */;
INSERT INTO `categorymetas` (`id`, `category_id`, `type`, `content`, `created_at`, `updated_at`) VALUES (1,1,'credit_charge','100','2020-12-31 13:07:41','2020-12-31 13:07:41'),(2,1,'excerpt','apartment','2020-12-31 13:07:41','2020-12-31 13:07:41'),(3,2,'credit_charge','150','2020-12-31 13:08:00','2020-12-31 13:08:00'),(4,2,'excerpt','villa','2020-12-31 13:08:00','2020-12-31 13:08:00'),(5,3,'credit_charge','120','2020-12-31 13:08:14','2020-12-31 13:08:14'),(6,3,'excerpt','House','2020-12-31 13:08:14','2020-12-31 13:08:14'),(7,4,'credit_charge','120','2020-12-31 13:08:30','2020-12-31 13:08:30'),(8,4,'excerpt','Condo','2020-12-31 13:08:30','2020-12-31 13:08:30'),(9,5,'credit_charge','100','2020-12-31 13:08:49','2020-12-31 13:08:49'),(10,5,'excerpt','land','2020-12-31 13:08:49','2020-12-31 13:08:49'),(11,6,'credit_charge','120','2020-12-31 13:09:13','2020-12-31 13:09:13'),(12,6,'excerpt','Commercial Property','2020-12-31 13:09:13','2020-12-31 13:09:37'),(13,14,'position','left','2020-12-31 13:16:50','2020-12-31 13:16:50'),(14,19,'preview','http://realestate.avanteca.com.bd/uploads/21/01/10012116102894065ffb10fe25db5.webp','2020-12-31 13:24:25','2021-01-10 19:37:13'),(15,19,'mapinfo','{\"latitude\":\"23.8103\",\"longitude\":\"90.4125\",\"zoom\":\"10\"}','2020-12-31 13:24:25','2020-12-31 13:24:25'),(16,20,'preview','http://realestate.avanteca.com.bd/uploads/21/01/10012116102894135ffb11055db3b.webp','2020-12-31 13:25:23','2021-01-10 19:36:58'),(17,20,'mapinfo','{\"latitude\":\"22.3569\",\"longitude\":\"91.7832\",\"zoom\":\"10\"}','2020-12-31 13:25:23','2020-12-31 13:25:23'),(18,21,'preview','','2020-12-31 13:27:36','2020-12-31 13:27:36'),(19,21,'mapinfo','{\"latitude\":\"23.8103\",\"longitude\":\"90.4125\",\"zoom\":\"10\"}','2020-12-31 13:27:36','2020-12-31 13:27:36'),(20,22,'preview','','2020-12-31 13:28:31','2020-12-31 13:28:31'),(21,22,'mapinfo','{\"latitude\":\"23.6019\",\"longitude\":\"89.8333\",\"zoom\":\"10\"}','2020-12-31 13:28:31','2020-12-31 13:28:31'),(22,23,'preview','','2020-12-31 13:29:17','2020-12-31 13:29:17'),(23,23,'mapinfo','{\"latitude\":\"22.3569\",\"longitude\":\"91.7282\",\"zoom\":\"10\"}','2020-12-31 13:29:17','2020-12-31 13:29:17'),(24,24,'preview','','2020-12-31 13:30:51','2020-12-31 13:30:51'),(25,24,'mapinfo','{\"latitude\":\"21.4272\",\"longitude\":\"92.0058\",\"zoom\":\"10\"}','2020-12-31 13:30:51','2020-12-31 13:30:51'),(26,31,'preview','http://realestate.avanteca.com.bd/uploads/21/01/10012116102905585ffb157edfcf8.webp','2021-01-10 19:56:28','2021-01-10 19:56:28'),(27,31,'mapinfo','{\"latitude\":\"24.3745\",\"longitude\":\"88.6042\",\"zoom\":\"10\"}','2021-01-10 19:56:28','2021-01-10 19:56:28'),(28,32,'preview','http://realestate.avanteca.com.bd/uploads/21/01/10012116102905605ffb158005816.webp','2021-01-10 19:57:58','2021-01-10 19:57:58'),(29,32,'mapinfo','{\"latitude\":\"23.1778\",\"longitude\":\"89.1801\",\"zoom\":\"10\"}','2021-01-10 19:57:58','2021-01-10 19:57:58'),(30,33,'preview','http://realestate.avanteca.com.bd/uploads/21/01/10012116102905595ffb157f46dcc.webp','2021-01-10 19:59:05','2021-01-10 19:59:05'),(31,33,'mapinfo','{\"latitude\":\"22.8456\",\"longitude\":\"89.5403\",\"zoom\":\"10\"}','2021-01-10 19:59:05','2021-01-10 19:59:05'),(32,34,'preview','http://realestate.avanteca.com.bd/uploads/21/01/10012116102905595ffb157fa23a5.webp','2021-01-10 20:02:50','2021-01-10 20:04:15'),(33,34,'mapinfo','{\"latitude\":\"24.8949\",\"longitude\":\"91.8687\",\"zoom\":\"10\"}','2021-01-10 20:02:50','2021-01-10 20:02:50'),(34,35,'icon','fas fa-wifi','2021-01-10 22:53:51','2021-01-10 22:53:51'),(35,36,'icon','fas fa-swimmer','2021-01-10 22:54:12','2021-01-10 22:54:12'),(36,37,'icon','fas fa-car-side','2021-01-10 22:54:37','2021-01-10 22:54:37'),(37,38,'icon','fas fa-user-secret','2021-01-10 22:54:57','2021-01-10 22:54:57'),(38,39,'icon','fas fa-hand-holding-heart','2021-01-10 22:55:39','2021-01-10 22:55:39'),(39,40,'icon','fas fa-archway','2021-01-10 22:56:00','2021-01-10 22:56:00'),(40,41,'icon','far fa-hospital','2021-01-10 23:01:58','2021-01-10 23:01:58'),(41,42,'icon','fas fa-shopping-cart','2021-01-10 23:02:45','2021-01-10 23:02:45'),(42,43,'icon','fas fa-school','2021-01-10 23:03:04','2021-01-10 23:03:04'),(43,44,'icon','fas fa-align-center','2021-01-10 23:03:20','2021-01-10 23:03:20'),(44,45,'icon','fas fa-hand-holding-heart','2021-01-10 23:04:00','2021-01-10 23:04:00'),(45,46,'icon','fab fa-angrycreative','2021-01-10 23:04:23','2021-01-10 23:04:23'),(46,47,'icon','fas fa-train','2021-01-10 23:04:35','2021-01-10 23:04:35'),(47,48,'icon','fas fa-bus','2021-01-10 23:04:50','2021-01-10 23:04:50'),(48,49,'icon','fas fa-umbrella-beach','2021-01-10 23:05:05','2021-01-10 23:05:05'),(49,50,'icon','fas fa-luggage-cart','2021-01-10 23:05:24','2021-01-10 23:05:24'),(50,51,'icon','fas fa-money-bill','2021-01-10 23:05:40','2021-01-10 23:05:40'),(51,17,'preview','http://realestate.avanteca.com.bd/uploads/21/01/11012116103399535ffbd67132cff.webp','2021-01-11 09:39:26','2021-01-11 09:39:26'),(52,16,'preview','http://realestate.avanteca.com.bd/uploads/21/01/11012116103399535ffbd671f06e5.webp','2021-01-11 09:39:50','2021-01-11 09:39:50'),(53,15,'preview','http://realestate.avanteca.com.bd/uploads/21/01/11012116103399535ffbd671f06e5.webp','2021-01-11 09:44:08','2021-01-11 09:44:08'),(54,52,'credit',NULL,'2021-01-11 19:53:21','2021-01-11 19:53:21'),(55,52,'preview','http://realestate.avanteca.com.bd/uploads/21/01/11012116103778575ffc6a81e5911.webp','2021-01-11 19:53:21','2021-01-11 20:11:04'),(56,52,'content','{\"address\":\"Dhaka, Savar\",\"phone\":\"096545345345\",\"description\":\"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\",\"facebook\":\"#\",\"twitter\":\"#\",\"youtube\":\"#\",\"pinterest\":\"#\",\"linkedin\":\"#\",\"instagram\":\"#\",\"whatsapp\":\"2342342342342\",\"service_area\":\"Dhaka, Khulna, Savar\",\"tax_number\":\"35235325353\",\"license\":\"32432523532532\",\"email\":\"support@email.com\"}','2021-01-11 19:53:21','2021-01-11 19:53:21'),(57,53,'credit',NULL,'2021-01-11 20:23:26','2021-01-11 20:23:26'),(58,53,'preview','http://realestate.avanteca.com.bd/uploads/21/01/11012116103785955ffc6d635efd4.webp','2021-01-11 20:23:26','2021-01-11 20:23:26'),(59,53,'content','{\"address\":\"Agrabad, Chittagong\",\"phone\":\"045345345345345\",\"description\":\"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.\",\"facebook\":\"#\",\"twitter\":\"#\",\"youtube\":\"#\",\"pinterest\":\"#\",\"linkedin\":\"#\",\"instagram\":\"#\",\"whatsapp\":\"547457457457\",\"service_area\":\"Naogaon, Dhaka, Kirtipur\",\"tax_number\":\"43653463463463\",\"license\":\"353456345353535\",\"email\":\"support@morden.com\"}','2021-01-11 20:23:26','2021-01-11 20:23:26'),(60,54,'credit',NULL,'2021-01-11 20:31:19','2021-01-11 20:31:19'),(61,54,'preview','http://realestate.avanteca.com.bd/uploads/21/01/11012116103785945ffc6d62d6210.webp','2021-01-11 20:31:19','2021-01-11 20:31:19'),(62,54,'content','{\"address\":\"Naogaon, Kirtipur\",\"phone\":\"034324324324324\",\"description\":\"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\",\"facebook\":\"#\",\"twitter\":\"#\",\"youtube\":\"#\",\"pinterest\":\"#\",\"linkedin\":\"#\",\"instagram\":\"#\",\"whatsapp\":\"#\",\"service_area\":\"Naogaon, Kirtipur, Mohadebpur\",\"tax_number\":\"345435345325325\",\"license\":\"3532532532532532523\",\"email\":\"support@company.com\"}','2021-01-11 20:31:19','2021-01-11 20:31:19'),(69,61,'lang','{\"lang_name\":\"English\",\"lang_position\":\"LTR\"}','2021-01-18 14:22:05','2021-01-18 14:22:05'),(70,62,'lang','{\"lang_name\":\"Arabic\",\"lang_position\":\"RTL\"}','2021-01-18 14:22:14','2021-01-18 14:22:14'),(71,63,'position','right','2020-12-31 13:16:50','2020-12-31 13:16:50'),(72,64,'credentials','{\"client_id\":\"\",\"client_secret\":\"\",\"currency\":\"USD\"}','2021-06-09 00:19:34','2021-06-09 00:19:34'),(73,65,'credentials','{\"publishable_key\":\"\",\"secret_key\":\"\",\"currency\":\"USD\"}','2021-06-09 00:19:34','2021-06-09 00:19:34'),(74,66,'credentials','{\"userSecretKey\":\"\",\"categoryCode\":\"\"}','2021-06-09 00:19:34','2021-06-09 00:19:34'),(75,67,'credentials','{\"key_id\":\"\",\"key_secret\":\"\",\"currency\":\"USD\"}','2021-06-09 00:19:34','2021-06-09 00:19:34'),(76,68,'credentials','{\"x_api_Key\":\"\",\"x_api_token\":\"\"}','2021-06-09 00:19:34','2021-06-09 00:19:34'),(77,69,'credentials','{\"api_key\":\"\",\"currency\":\"USD\"}','2021-06-09 00:19:34','2021-06-09 00:19:34');
/*!40000 ALTER TABLE `categorymetas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categoryrelations`
--

DROP TABLE IF EXISTS `categoryrelations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categoryrelations` (
  `parent_id` bigint(20) unsigned NOT NULL,
  `child_id` bigint(20) unsigned NOT NULL,
  KEY `categoryrelations_parent_id_foreign` (`parent_id`),
  KEY `categoryrelations_child_id_foreign` (`child_id`),
  CONSTRAINT `categoryrelations_child_id_foreign` FOREIGN KEY (`child_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categoryrelations_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoryrelations`
--

LOCK TABLES `categoryrelations` WRITE;
/*!40000 ALTER TABLE `categoryrelations` DISABLE KEYS */;
INSERT INTO `categoryrelations` (`parent_id`, `child_id`) VALUES (18,4),(17,1),(17,2),(17,3),(17,4),(17,5),(17,6),(16,1),(16,2),(16,3),(16,4),(16,5),(16,6),(15,6);
/*!40000 ALTER TABLE `categoryrelations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categoryusers`
--

DROP TABLE IF EXISTS `categoryusers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categoryusers` (
  `category_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  KEY `categoryusers_user_id_foreign` (`user_id`),
  KEY `categoryusers_category_id_foreign` (`category_id`),
  CONSTRAINT `categoryusers_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categoryusers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoryusers`
--

LOCK TABLES `categoryusers` WRITE;
/*!40000 ALTER TABLE `categoryusers` DISABLE KEYS */;
INSERT INTO `categoryusers` (`category_id`, `user_id`) VALUES (52,2),(52,3),(52,4),(53,2),(53,3),(53,4),(54,2),(54,3),(54,4);
/*!40000 ALTER TABLE `categoryusers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customizers`
--

DROP TABLE IF EXISTS `customizers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customizers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customizers`
--

LOCK TABLES `customizers` WRITE;
/*!40000 ALTER TABLE `customizers` DISABLE KEYS */;
INSERT INTO `customizers` (`id`, `key`, `theme_name`, `value`, `status`, `created_at`, `updated_at`) VALUES (1,'property_agents','jomidar','{\"settings\":{\"property_agent_title\":{\"old_value\":null,\"new_value\":\"Property Agents\"},\"property_agent_descrtiption\":{\"old_value\":null,\"new_value\":\"Proportioned interiors Club over 10,000 square feet\"},\"property_agent_btn_title\":{\"old_value\":null,\"new_value\":\"View All Agents\"}}}','1','2020-11-20 14:09:16','2020-11-20 14:11:06'),(2,'hero','jomidar','{\"settings\":{\"hero_big_title\":{\"old_value\":null,\"new_value\":\"Best Place To Find Dream Home.\"},\"hero_des\":{\"old_value\":null,\"new_value\":\"From as low as $10 per day with limited time offer discounts.\"},\"hero_address_placeholder\":{\"old_value\":null,\"new_value\":\"Enter keyword\"},\"hero_search_btn\":{\"old_value\":null,\"new_value\":\"Search\"},\"hero_background_img\":{\"old_value\":null,\"new_value\":\"uploads\\/2020-11-20-5fb7880d921db.jpg\"}}}','1','2020-11-20 14:10:04','2020-11-20 14:11:06'),(3,'header','jomidar','{\"settings\":{\"logo\":{\"old_value\":\"uploads\\/2020-11-20-5fb78818a17c8.png\",\"new_value\":\"uploads\\/2021-06-08-60bfd60ad974c.png\"},\"header_signin_title\":{\"old_value\":null,\"new_value\":\"Sign In\"},\"header_create_property_title\":{\"old_value\":null,\"new_value\":\"Create Property\"},\"header_phone_number\":{\"old_value\":\"+0433423242331\",\"new_value\":\"+ 0434610979\"},\"header_email_address\":{\"old_value\":\"support@amcoders.com\",\"new_value\":\"support@wonderit.com.au\"}}}','1','2020-11-20 14:10:48','2021-06-09 00:41:49'),(4,'featured_properties','jomidar','{\"settings\":{\"featured_properties_title\":{\"old_value\":null,\"new_value\":\"Featured Properties\"},\"featured_properties_des\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"},\"featured_properties_btn_title\":{\"old_value\":null,\"new_value\":\"View All Properties\"}}}','1','2020-11-20 14:17:55','2020-11-20 14:18:28'),(5,'find_city','jomidar','{\"settings\":{\"find_city_bg_img\":{\"old_value\":null,\"new_value\":\"uploads\\/2020-11-20-5fb78ac53aa98.jpg\"},\"find_city_title\":{\"old_value\":null,\"new_value\":\"Find us in these cities\"},\"find_city_des\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"}}}','1','2020-11-20 14:22:13','2020-11-20 14:22:32'),(6,'blog_list','jomidar','{\"settings\":{\"blog_list_title\":{\"old_value\":\"All Blogs\",\"new_value\":\"All Blogs\"},\"blog_list_des\":{\"old_value\":null,\"new_value\":\"Proportioned interiors Club over 10,000 square feet\"},\"blog_list_btn_title\":{\"old_value\":null,\"new_value\":\"View All Blogs\"}}}','1','2020-11-20 14:25:44','2020-11-20 14:26:15'),(7,'footer','jomidar','{\"settings\":{\"footer_image\":{\"old_value\":\"uploads\\/2020-11-20-5fb792e445c04.png\",\"new_value\":\"uploads\\/2021-06-08-60bfd753ad190.png\"},\"footer_des\":{\"old_value\":\"Maruf\",\"new_value\":\"Lorem ipsum dolor sit amet, consect etur adi pisicing elit sed do eiusmod tempor incididunt ut labore.\"},\"footer_copyright\":{\"old_value\":\"Copyright \\u00a9 Website - 2020. Design By Amcoders\",\"new_value\":\"Copyright \\u00a9 Website - 2021. Developed By Wonder IT\"}},\"content\":{\"footer_right\":{\"footer_right_title\":{\"old_value\":null,\"new_value\":\"Newsletter\"},\"footer_right_des\":{\"old_value\":\"Unit 11, 60 Epping Road, Lane Cove\\nNSW 2066.\\nneedhelp@ziston.com\",\"new_value\":\"Unit 11, 60 Epping Road, Lane Cove\\nNSW 2066.\\nsupport@wonderit.com.au\"},\"footer_right_btn_title\":{\"old_value\":null,\"new_value\":\"Subscribe\"}}}}','1','2020-11-20 14:56:52','2021-06-09 00:47:18'),(8,'blog_breadcrumb','jomidar','{\"settings\":{\"bg_breadcrumb_img\":{\"old_value\":\"uploads\\/2021-01-12-5ffdd9e633477.jpg\",\"new_value\":\"uploads\\/2021-01-12-5ffddab2e1121.jpg\"},\"breadcrumb_title\":{\"old_value\":null,\"new_value\":\"Blog Lists\"},\"breadcrumb_des\":{\"old_value\":null,\"new_value\":\"Blog Lists\"},\"bg_blog_breadcrumb_img\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-01-12-5ffddada9c2c4.jpg\"}}}','1','2021-01-12 22:18:30','2021-01-12 22:22:36'),(9,'agency_list_breadcrumb','jomidar','{\"settings\":{\"bg_breadcrumb_img\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-01-12-5ffdda0a49b41.jpg\"},\"breadcrumb_title\":{\"old_value\":null,\"new_value\":\"Agency Lists\"},\"breadcrumb_des\":{\"old_value\":null,\"new_value\":\"Agency Lists\"},\"breadcrumb_agency_title\":{\"old_value\":null,\"new_value\":\"All Agency\"},\"breadcrumb_agency_des\":{\"old_value\":null,\"new_value\":\"All Agency\"}}}','1','2021-01-12 22:19:06','2021-01-21 05:15:11'),(10,'breadcrumb','jomidar','{\"settings\":{\"bg_breadcrumb_img\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-01-12-5ffdda1eb1adb.jpg\"},\"breadcrumb_title\":{\"old_value\":null,\"new_value\":\"Agent Lists\"},\"breadcrumb_des\":{\"old_value\":null,\"new_value\":\"Agent Lists\"},\"breadcrumb_agent_title\":{\"old_value\":null,\"new_value\":\"All Agents\"},\"breadcrumb_agent_des\":{\"old_value\":null,\"new_value\":\"All Agents\"}}}','1','2021-01-12 22:19:26','2021-01-21 05:14:49'),(11,'header','zamindar','{\"settings\":{\"header_phone_number\":{\"old_value\":\"4354354364443\",\"new_value\":\"435435436444\"},\"header_email_address\":{\"old_value\":null,\"new_value\":\"support@amcoders.com\"},\"logo\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-01-24-600d4506f0667.png\"},\"header_signin_title\":{\"old_value\":null,\"new_value\":\"Sign In\"},\"header_create_property_title\":{\"old_value\":null,\"new_value\":\"Create Property\"}}}','1','2021-01-24 20:58:44','2021-01-24 21:00:32'),(12,'featured_properties','zamindar','{\"settings\":{\"featured_properties_title\":{\"old_value\":\"Latest Property\",\"new_value\":\"Latest Properties\"},\"featured_properties_des\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"},\"featured_properties_btn_title\":{\"old_value\":null,\"new_value\":\"View All Properties\"}}}','1','2021-01-24 21:00:57','2021-01-24 21:01:25'),(13,'blog_list','zamindar','{\"settings\":{\"blog_list_title\":{\"old_value\":null,\"new_value\":\"Latest Blogs\"},\"blog_list_des\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"},\"blog_list_btn_title\":{\"old_value\":null,\"new_value\":\"View All Blogs\"}}}','1','2021-01-24 21:01:46','2021-01-24 21:02:04'),(14,'footer','zamindar','{\"settings\":{\"footer_image\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-01-24-600d45bb7e54d.png\"},\"footer_des\":{\"old_value\":null,\"new_value\":\"Lorem ipsum dolor sit amet, consect etur adi pisicing elit sed do eiusmod tempor incididunt ut labore.\"},\"footer_copyright\":{\"old_value\":null,\"new_value\":\"Copyright \\u00a9 Jomidar - 2020. Design By Amcoders\"}},\"content\":{\"\":{\"social_facebook_link\":{\"old_value\":null,\"new_value\":\"#\"},\"social_twitter_link\":{\"old_value\":null,\"new_value\":\"#\"},\"social_google_link\":{\"old_value\":null,\"new_value\":\"#\"},\"social_instagram_link\":{\"old_value\":null,\"new_value\":\"#\"},\"social_pinterest_link\":{\"old_value\":null,\"new_value\":\"#\"}},\"footer_right\":{\"footer_right_title\":{\"old_value\":null,\"new_value\":\"Newsletter\"},\"footer_right_des\":{\"old_value\":null,\"new_value\":\"88 Broklyn Golden Street, New York. USA needhelp@ziston.com\"},\"footer_right_btn_title\":{\"old_value\":null,\"new_value\":\"Subscribe\"}}}}','1','2021-01-24 21:02:35','2021-01-24 21:03:48'),(15,'hero','zamindar','{\"settings\":{\"hero_background_img\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-01-24-600da81638203.jpg\"},\"hero_big_title\":{\"old_value\":null,\"new_value\":\"Fast way to achieve your goals in business\"},\"hero_des\":{\"old_value\":null,\"new_value\":\"To an English person, it will seem like simplified English, as a skeptical Cambridge friend of mine occidental\"},\"hero_btn_title\":{\"old_value\":null,\"new_value\":\"Learn More\"},\"hero_btn_link\":{\"old_value\":null,\"new_value\":\"#\"},\"hero_address_placeholder\":{\"old_value\":null,\"new_value\":\"Enter Your Address\"},\"hero_search_btn\":{\"old_value\":null,\"new_value\":\"Search\"}}}','1','2021-01-25 04:02:14','2021-01-25 04:03:36'),(16,'find_city','zamindar','{\"settings\":{\"find_city_title\":{\"old_value\":\"Find us in your city\",\"new_value\":\"Find us in your city\"},\"find_city_des\":{\"old_value\":\"Handpicked Exclusive Properties By Our Team.\",\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"},\"city_btn_title\":{\"old_value\":null,\"new_value\":\"View All City\"}}}','1','2021-01-25 04:23:20','2021-01-25 04:24:44'),(17,'property_agents','zamindar','{\"settings\":{\"property_agent_title\":{\"old_value\":null,\"new_value\":\"Property Agents\"},\"property_agent_descrtiption\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"},\"property_agent_btn_title\":{\"old_value\":null,\"new_value\":\"View All Agents\"}}}','1','2021-01-25 04:37:51','2021-01-25 04:38:15'),(18,'counter','zamindar','{\"content\":{\"counter_first_section\":{\"counter_first_section_title\":{\"old_value\":\"to\",\"new_value\":\"Total Agents\"},\"counter_first_section_count\":{\"old_value\":null,\"new_value\":\"880\"}},\"counter_second_section\":{\"counter_second_section_title\":{\"old_value\":null,\"new_value\":\"Total Sales\"},\"counter_second_section_count\":{\"old_value\":null,\"new_value\":\"1798\"}},\"counter_third_section\":{\"counter_third_section_title\":{\"old_value\":null,\"new_value\":\"Total Projects\"},\"counter_third_section_count\":{\"old_value\":null,\"new_value\":\"582\"}},\"counter_four_section\":{\"counter_four_section_title\":{\"old_value\":null,\"new_value\":\"Total Customers\"},\"counter_four_section_count\":{\"old_value\":null,\"new_value\":\"3698\"}}},\"settings\":{\"counter_bg_img\":{\"old_value\":\"uploads\\/2021-01-25-600e4f6bf146a.png\",\"new_value\":\"uploads\\/2021-01-25-600e4fa1d2490.jpg\"}}}','1','2021-01-25 15:50:05','2021-01-25 15:58:05'),(19,'header','bari','{\"settings\":{\"header_phone_number\":{\"old_value\":\"+97867855656\",\"new_value\":\"4354354364443\"},\"header_email_address\":{\"old_value\":\"support@amcod\",\"new_value\":\"support@amcoders.com\"},\"logo\":{\"old_value\":\"uploads\\/2021-01-27-601191c16b1fd.png\",\"new_value\":\"uploads\\/2021-01-27-601191c5582e8.png\"},\"header_create_property_title\":{\"old_value\":\"Create Property\",\"new_value\":\"Create Property\"}}}','1','2021-01-28 03:11:34','2021-01-28 03:16:39'),(20,'hero','bari','{\"settings\":{\"hero_background_img\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-01-27-60119119268d7.jpg\"},\"hero_big_title\":{\"old_value\":null,\"new_value\":\"Discover Your Best Place to Live\"},\"hero_des\":{\"old_value\":null,\"new_value\":\"To an English person, it will seem like simplified English, as a skeptical Cambridge friend of mine occidental\"},\"hero_first_btn_title\":{\"old_value\":null,\"new_value\":\"Learn More\"},\"hero_second_btn_title\":{\"old_value\":null,\"new_value\":\"View Details\"},\"hero_first_btn_link\":{\"old_value\":null,\"new_value\":\"#\"},\"hero_second_btn_link\":{\"old_value\":null,\"new_value\":\"#\"}}}','1','2021-01-28 03:13:13','2021-01-28 03:14:06'),(21,'featured_properties','bari','{\"settings\":{\"featured_properties_title\":{\"old_value\":null,\"new_value\":\"Latest Properties\"},\"featured_properties_des\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"},\"featured_properties_btn_title\":{\"old_value\":null,\"new_value\":\"View All Properties\"}}}','1','2021-01-28 03:16:52','2021-01-28 03:17:17'),(22,'property_agents','bari','{\"settings\":{\"property_agent_title\":{\"old_value\":null,\"new_value\":\"Property Agents\"},\"property_agent_descrtiption\":{\"old_value\":null,\"new_value\":\"Proportioned interiors Club over 10,000 square feet\"},\"property_agent_btn_title\":{\"old_value\":null,\"new_value\":\"View All Agents\"}}}','1','2021-01-28 03:17:55','2021-01-28 03:18:21'),(23,'find_city','bari','{\"settings\":{\"find_city_title\":{\"old_value\":null,\"new_value\":\"Find us in your city\"},\"find_city_des\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"}}}','1','2021-01-28 03:18:27','2021-01-28 03:18:47'),(24,'blog_list','bari','{\"settings\":{\"blog_list_title\":{\"old_value\":null,\"new_value\":\"Latest Blogs\"},\"blog_list_des\":{\"old_value\":null,\"new_value\":\"Proportioned interiors Club over 10,000 square feet\"},\"blog_list_btn_title\":{\"old_value\":null,\"new_value\":\"View All Blogs\"}}}','1','2021-01-28 03:19:00','2021-01-28 03:19:12'),(25,'footer','bari','{\"settings\":{\"footer_image\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-01-27-6011928987ddb.png\"},\"footer_des\":{\"old_value\":null,\"new_value\":\"Lorem ipsum dolor sit amet, consect etur adi pisicing elit sed do eiusmod tempor incididunt ut labore.\"},\"footer_copyright\":{\"old_value\":null,\"new_value\":\"Copyright \\u00a9 Website - 2020. Design By Amcoders\"}},\"content\":{\"\":{\"social_facebook_link\":{\"old_value\":null,\"new_value\":\"#\"},\"social_twitter_link\":{\"old_value\":null,\"new_value\":\"#\"},\"social_google_link\":{\"old_value\":null,\"new_value\":\"#\"},\"social_instagram_link\":{\"old_value\":null,\"new_value\":\"#\"},\"social_pinterest_link\":{\"old_value\":null,\"new_value\":\"#\"}},\"footer_right\":{\"footer_right_title\":{\"old_value\":null,\"new_value\":\"Newsletter\"},\"footer_right_des\":{\"old_value\":null,\"new_value\":\"88 Broklyn Golden Street, New York. USA needhelp@ziston.com\"},\"footer_right_btn_title\":{\"old_value\":null,\"new_value\":\"Subscribe\"}}}}','1','2021-01-28 03:19:21','2021-01-28 03:20:15'),(26,'hero','hazibari','{\"settings\":{\"hero_background_img\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-01-29-601412e0f0233.jpg\"},\"hero_big_title\":{\"old_value\":null,\"new_value\":\"Find Your Future Home\"}}}','1','2021-01-30 00:51:29','2021-01-30 00:51:39'),(27,'find_city','hazibari','{\"settings\":{\"find_city_title\":{\"old_value\":null,\"new_value\":\"Find us in your city\"},\"find_city_des\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"}}}','1','2021-01-30 00:56:22','2021-01-30 00:56:34'),(28,'blog_list','hazibari','{\"settings\":{\"blog_list_title\":{\"old_value\":null,\"new_value\":\"Latest Blogs\"},\"blog_list_des\":{\"old_value\":null,\"new_value\":\"Proportioned interiors Club over 10,000 square feet\"},\"blog_list_btn_title\":{\"old_value\":null,\"new_value\":\"View All Blogs\"}}}','1','2021-01-30 01:05:25','2021-01-30 01:07:49'),(29,'footer','hazibari','{\"settings\":{\"footer_image\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-01-29-6014164031f32.png\"},\"footer_des\":{\"old_value\":null,\"new_value\":\"Lorem ipsum dolor sit amet, consect etur adi pisicing elit sed do eiusmod tempor incididunt ut labore.\"},\"footer_copyright\":{\"old_value\":null,\"new_value\":\"Copyright \\u00a9 Website - 2020. Design By Amcoders\"}},\"content\":{\"\":{\"social_facebook_link\":{\"old_value\":\"#ede\",\"new_value\":\"fgfg\"},\"social_twitter_link\":{\"old_value\":\"#\",\"new_value\":\"dfdfdsf\"},\"social_google_link\":{\"old_value\":null,\"new_value\":\"#\"},\"social_instagram_link\":{\"old_value\":null,\"new_value\":\"#\"},\"social_pinterest_link\":{\"old_value\":null,\"new_value\":\"#\"}},\"footer_right\":{\"footer_right_title\":{\"old_value\":null,\"new_value\":\"Newsletter\"},\"footer_right_des\":{\"old_value\":null,\"new_value\":\"88 Broklyn Golden Street, New York. USA needhelp@ziston.com\"},\"footer_right_btn_title\":{\"old_value\":null,\"new_value\":\"Subscribe\"}}}}','1','2021-01-30 01:05:52','2021-01-30 01:09:07'),(30,'featured_properties','hazibari','{\"settings\":{\"featured_properties_title\":{\"old_value\":null,\"new_value\":\"Latest Properties\"},\"featured_properties_des\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"},\"featured_properties_btn_title\":{\"old_value\":null,\"new_value\":\"View All Properties\"}}}','1','2021-01-30 01:14:56','2021-01-30 01:15:15'),(31,'review','hazibari','{\"settings\":{\"review_bg_img\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-01-29-601419b6c2696.png\"},\"review_title\":{\"old_value\":null,\"new_value\":\"Good Reviews By Clients\"},\"review_des\":{\"old_value\":null,\"new_value\":\"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.\"}}}','1','2021-01-30 01:20:38','2021-01-30 01:21:17'),(32,'header','thakorbari','{\"settings\":{\"header_phone_number\":{\"old_value\":null,\"new_value\":\"4354354364443\"},\"header_email_address\":{\"old_value\":null,\"new_value\":\"support@amcoders.com\"},\"logo\":{\"old_value\":\"uploads\\/2021-01-30-6015670368313.png\",\"new_value\":\"uploads\\/2021-01-30-60156786463dc.png\"},\"header_signin_title\":{\"old_value\":null,\"new_value\":\"Sign In\"},\"header_create_property_title\":{\"old_value\":null,\"new_value\":\"Create Property\"}}}','1','2021-01-31 01:02:09','2021-01-31 01:05:00'),(33,'hero','thakorbari','{\"settings\":{\"hero_background_img\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-01-30-60156797f0bab.png\"},\"hero_big_title\":{\"old_value\":null,\"new_value\":\"GET A PROPERTY NOW @ AFFORDABLE PRICE\"},\"hero_des\":{\"old_value\":null,\"new_value\":\"Making Real Estate Simple & Easier for your Business or your Family\"},\"hero_address_placeholder\":{\"old_value\":null,\"new_value\":\"Location\"},\"hero_search_btn\":{\"old_value\":null,\"new_value\":\"Search\"}}}','1','2021-01-31 01:05:12','2021-01-31 01:05:49'),(34,'featured_properties','thakorbari','{\"settings\":{\"featured_properties_title\":{\"old_value\":null,\"new_value\":\"Latest Properties\"},\"featured_properties_des\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"},\"featured_properties_btn_title\":{\"old_value\":null,\"new_value\":\"View All Properties\"}}}','1','2021-01-31 01:10:31','2021-01-31 01:13:11'),(35,'counter','thakorbari','{\"settings\":{\"counter_bg_img\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-01-30-601568fe127bc.jpg\"}},\"content\":{\"counter_first_section\":{\"counter_first_section_title\":{\"old_value\":null,\"new_value\":\"Total Agents\"},\"counter_first_section_count\":{\"old_value\":null,\"new_value\":\"880\"}},\"counter_second_section\":{\"counter_second_section_title\":{\"old_value\":null,\"new_value\":\"Total Sales\"},\"counter_second_section_count\":{\"old_value\":null,\"new_value\":\"1798\"}},\"counter_third_section\":{\"counter_third_section_title\":{\"old_value\":null,\"new_value\":\"Total Projects\"},\"counter_third_section_count\":{\"old_value\":null,\"new_value\":\"582\"}},\"counter_four_section\":{\"counter_four_section_title\":{\"old_value\":null,\"new_value\":\"Total Customers\"},\"counter_four_section_count\":{\"old_value\":null,\"new_value\":\"3698\"}}}}','1','2021-01-31 01:11:10','2021-01-31 01:13:11'),(36,'blog_list','thakorbari','{\"settings\":{\"blog_list_title\":{\"old_value\":null,\"new_value\":\"Latest Blogs\"},\"blog_list_des\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"},\"blog_list_btn_title\":{\"old_value\":null,\"new_value\":\"View All Blogs\"}}}','1','2021-01-31 01:11:52','2021-01-31 01:13:11'),(37,'footer','thakorbari','{\"settings\":{\"footer_image\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-01-30-60156938d54e6.png\"},\"footer_des\":{\"old_value\":null,\"new_value\":\"Lorem ipsum dolor sit amet, consect etur adi pisicing elit sed do eiusmod tempor incididunt ut labore.\"},\"footer_copyright\":{\"old_value\":null,\"new_value\":\"Copyright \\u00a9 Website - 2020. Design By Amcoders\"}},\"content\":{\"footer_right\":{\"footer_right_title\":{\"old_value\":null,\"new_value\":\"Newsletter\"},\"footer_right_des\":{\"old_value\":null,\"new_value\":\"88 Broklyn Golden Street, New York. USA needhelp@ziston.com\"},\"footer_right_btn_title\":{\"old_value\":null,\"new_value\":\"Subscribe\"}}}}','1','2021-01-31 01:12:08','2021-01-31 01:13:12'),(38,'property_agents','thakorbari','{\"settings\":{\"property_agent_title\":{\"old_value\":null,\"new_value\":\"Property Agents\"},\"property_agent_descrtiption\":{\"old_value\":null,\"new_value\":\"Proportioned interiors Club over 10,000 square feet\"},\"property_agent_btn_title\":{\"old_value\":null,\"new_value\":\"View All Agents\"}}}','1','2021-01-31 01:20:34','2021-01-31 01:21:04'),(39,'header','amarbari','{\"settings\":{\"header_phone_number\":{\"old_value\":\"4354354364443\",\"new_value\":\"4354354364443\"},\"header_email_address\":{\"old_value\":\"support@amcoders.com\",\"new_value\":\"support@amcoders.com\"},\"logo\":{\"old_value\":\"uploads\\/2021-01-30-60156ed56440f.png\",\"new_value\":\"uploads\\/2021-01-30-60156ee761243.png\"},\"header_create_property_title\":{\"old_value\":\"Create Property\",\"new_value\":\"Create Property\"}}}','1','2021-01-31 01:35:55','2021-01-31 01:36:27'),(40,'hero','amarbari','{\"settings\":{\"hero_background_img\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-01-30-60156f299d0ba.jpg\"},\"hero_big_title\":{\"old_value\":null,\"new_value\":\"Best Place To Live\"},\"hero_des\":{\"old_value\":null,\"new_value\":\"In the heart of Brooklyn, in a vibrant neighborhood just east of Prospect Park, stands an eight-story, full-service, strikingly beautiful apartment building\"},\"hero_first_btn_title\":{\"old_value\":null,\"new_value\":\"Learn More\"},\"hero_first_btn_link\":{\"old_value\":null,\"new_value\":\"#\"}}}','1','2021-01-31 01:37:29','2021-01-31 01:38:00'),(41,'featured_properties','amarbari','{\"settings\":{\"featured_properties_title\":{\"old_value\":null,\"new_value\":\"Latest Properties\"},\"featured_properties_des\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"},\"featured_properties_btn_title\":{\"old_value\":null,\"new_value\":\"View All Properties\"}}}','1','2021-01-31 01:38:05','2021-01-31 01:39:43'),(42,'find_city','amarbari','{\"settings\":{\"find_city_title\":{\"old_value\":null,\"new_value\":\"Find us in your city\"},\"find_city_des\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"}}}','1','2021-01-31 01:38:30','2021-01-31 01:39:43'),(43,'property_agents','amarbari','{\"settings\":{\"property_agent_title\":{\"old_value\":null,\"new_value\":\"Property Agents\"},\"property_agent_descrtiption\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"},\"property_agent_btn_title\":{\"old_value\":null,\"new_value\":\"View All Agents\"}}}','1','2021-01-31 01:38:39','2021-01-31 01:39:43'),(44,'blog_list','amarbari','{\"settings\":{\"blog_list_title\":{\"old_value\":null,\"new_value\":\"Latest Blogs\"},\"blog_list_des\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"},\"blog_list_btn_title\":{\"old_value\":null,\"new_value\":\"View All Blogs\"}}}','1','2021-01-31 01:38:50','2021-01-31 01:39:43'),(45,'footer','amarbari','{\"settings\":{\"footer_image\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-01-30-60156f85e77bb.png\"},\"footer_des\":{\"old_value\":null,\"new_value\":\"Lorem ipsum dolor sit amet, consect etur adi pisicing elit sed do eiusmod tempor incididunt ut labore.\"}},\"content\":{\"footer_right\":{\"footer_right_title\":{\"old_value\":null,\"new_value\":\"Newsletter\"},\"footer_right_des\":{\"old_value\":null,\"new_value\":\"88 Broklyn Golden Street, New York. USA needhelp@ziston.com\"},\"footer_right_btn_title\":{\"old_value\":null,\"new_value\":\"Subscribe\"}}}}','1','2021-01-31 01:39:02','2021-01-31 01:39:43'),(46,'header','marufbari','{\"settings\":{\"header_phone_number\":{\"old_value\":null,\"new_value\":\"4354354364443\"},\"header_email_address\":{\"old_value\":null,\"new_value\":\"support@amcoders.com\"},\"logo\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-01-31-6016435bf23c8.png\"},\"header_signin_title\":{\"old_value\":null,\"new_value\":\"Sign In\"},\"header_create_property_title\":{\"old_value\":null,\"new_value\":\"Create Property\"}}}','1','2021-01-31 16:42:46','2021-01-31 16:45:07'),(47,'hero','marufbari','{\"settings\":{\"hero_big_title\":{\"old_value\":\"GET A PROPERTY NOW @ AFFORDABLE PRICE\",\"new_value\":\"Find the good out there.\"},\"hero_search_btn\":{\"old_value\":null,\"new_value\":\"Search\"}}}','1','2021-01-31 16:43:00','2021-01-31 16:45:07'),(48,'featured_properties','marufbari','{\"settings\":{\"featured_properties_title\":{\"old_value\":null,\"new_value\":\"Latest Properties\"},\"featured_properties_des\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"},\"featured_properties_btn_title\":{\"old_value\":null,\"new_value\":\"View All Properties\"}}}','1','2021-01-31 16:43:21','2021-01-31 16:45:07'),(49,'counter','marufbari','{\"content\":{\"counter_first_section\":{\"counter_first_section_title\":{\"old_value\":null,\"new_value\":\"Total Agents\"},\"counter_first_section_count\":{\"old_value\":null,\"new_value\":\"880\"}},\"counter_second_section\":{\"counter_second_section_title\":{\"old_value\":null,\"new_value\":\"Total Sales\"},\"counter_second_section_count\":{\"old_value\":null,\"new_value\":\"1798\"}},\"counter_third_section\":{\"counter_third_section_title\":{\"old_value\":null,\"new_value\":\"Total Projects\"},\"counter_third_section_count\":{\"old_value\":null,\"new_value\":\"582\"}},\"counter_four_section\":{\"counter_four_section_title\":{\"old_value\":null,\"new_value\":\"Total Customers\"},\"counter_four_section_count\":{\"old_value\":null,\"new_value\":\"3698\"}}},\"settings\":{\"counter_bg_img\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-01-31-6016439283281.jpg\"}}}','1','2021-01-31 16:43:46','2021-01-31 16:45:07'),(50,'find_city','marufbari','{\"settings\":{\"find_city_title\":{\"old_value\":null,\"new_value\":\"Find us in your city\"},\"find_city_des\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"}}}','1','2021-01-31 16:44:03','2021-01-31 16:45:07'),(51,'blog_list','marufbari','{\"settings\":{\"blog_list_title\":{\"old_value\":null,\"new_value\":\"Latest Blogs\"},\"blog_list_des\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"},\"blog_list_btn_title\":{\"old_value\":null,\"new_value\":\"View All Blogs\"}}}','1','2021-01-31 16:44:14','2021-01-31 16:45:07'),(52,'footer','marufbari','{\"settings\":{\"footer_image\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-01-31-601643ba73deb.png\"},\"footer_des\":{\"old_value\":null,\"new_value\":\"Lorem ipsum dolor sit amet, consect etur adi pisicing elit sed do eiusmod tempor incididunt ut labore.\"},\"footer_copyright\":{\"old_value\":null,\"new_value\":\"Copyright \\u00a9 Website - 2020. Design By Amcoders\"}},\"content\":{\"footer_right\":{\"footer_right_title\":{\"old_value\":null,\"new_value\":\"Newsletter\"},\"footer_right_des\":{\"old_value\":null,\"new_value\":\"88 Broklyn Golden Street, New York. USA needhelp@ziston.com\"},\"footer_right_btn_title\":{\"old_value\":null,\"new_value\":\"Subscribe\"}}}}','1','2021-01-31 16:44:26','2021-01-31 16:45:07'),(53,'hero','arafatbari','{\"settings\":{\"hero_background_img\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-01-31-60168e1be3e26.jpg\"},\"hero_big_title\":{\"old_value\":null,\"new_value\":\"Find Your Dream Property\"},\"hero_des\":{\"old_value\":null,\"new_value\":\"We have lots of properties in various locations available for purchase.\"},\"hero_address_placeholder\":{\"old_value\":null,\"new_value\":\"Location\"},\"hero_search_btn\":{\"old_value\":null,\"new_value\":\"Search\"}}}','1','2021-01-31 22:01:48','2021-01-31 22:02:59'),(54,'header','arafatbari','{\"settings\":{\"header_phone_number\":{\"old_value\":null,\"new_value\":\"4354354364443\"},\"header_email_address\":{\"old_value\":null,\"new_value\":\"support@amcoders.com\"},\"logo\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-01-31-60168e4ade2a3.png\"},\"header_signin_title\":{\"old_value\":null,\"new_value\":\"Sign In\"},\"header_create_property_title\":{\"old_value\":null,\"new_value\":\"Create Property\"}}}','1','2021-01-31 22:02:25','2021-01-31 22:02:59'),(55,'featured_properties','arafatbari','{\"settings\":{\"featured_properties_title\":{\"old_value\":null,\"new_value\":\"Latest Properties\"},\"featured_properties_btn_title\":{\"old_value\":null,\"new_value\":\"View All Properties\"},\"featured_properties_des\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"}}}','1','2021-01-31 22:02:44','2021-01-31 22:02:59'),(56,'find_city','arafatbari','{\"settings\":{\"find_city_title\":{\"old_value\":null,\"new_value\":\"Find us in your city\"},\"find_city_des\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"}}}','1','2021-01-31 22:03:09','2021-01-31 22:03:14'),(57,'review','arafatbari','{\"settings\":{\"review_bg_img\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-01-31-60168e7d04c0e.png\"},\"review_title\":{\"old_value\":null,\"new_value\":\"Good Reviews By Clients\"},\"review_des\":{\"old_value\":null,\"new_value\":\"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.\"}}}','1','2021-01-31 22:03:25','2021-01-31 22:04:55'),(58,'blog_list','arafatbari','{\"settings\":{\"blog_list_title\":{\"old_value\":null,\"new_value\":\"Latest Blogs\"},\"blog_list_des\":{\"old_value\":null,\"new_value\":\"Proportioned interiors Club over 10,000 square feet\"},\"blog_list_btn_title\":{\"old_value\":null,\"new_value\":\"View All Blogs\"}}}','1','2021-01-31 22:03:54','2021-01-31 22:04:55'),(59,'footer','arafatbari','{\"settings\":{\"footer_image\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-01-31-60168eafa6db7.png\"},\"footer_des\":{\"old_value\":null,\"new_value\":\"Lorem ipsum dolor sit amet, consect etur adi pisicing elit sed do eiusmod tempor incididunt ut labore.\"},\"footer_copyright\":{\"old_value\":null,\"new_value\":\"Copyright \\u00a9 Website - 2020. Design By Amcoders\"}},\"content\":{\"footer_right\":{\"footer_right_title\":{\"old_value\":null,\"new_value\":\"Newsletter\"},\"footer_right_des\":{\"old_value\":null,\"new_value\":\"88 Broklyn Golden Street, New York. USA needhelp@ziston.com\"},\"footer_right_btn_title\":{\"old_value\":null,\"new_value\":\"Subscribe\"}}}}','1','2021-01-31 22:04:15','2021-01-31 22:04:55'),(60,'header','hellobari','{\"settings\":{\"header_phone_number\":{\"old_value\":null,\"new_value\":\"4354354364443\"},\"header_email_address\":{\"old_value\":null,\"new_value\":\"support@amcoders.com\"},\"logo\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-02-06-601d8afbf1ff1.png\"},\"header_signin_title\":{\"old_value\":null,\"new_value\":\"Sign In\"},\"header_create_property_title\":{\"old_value\":null,\"new_value\":\"Create Property\"}}}','1','2021-02-06 05:14:07','2021-02-06 05:14:26'),(61,'hero','hellobari','{\"settings\":{\"hero_bg_img\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-02-22-6033df3a185af.jpg\"}}}','1','2021-02-23 03:43:38','2021-02-23 03:46:23'),(62,'featured_properties','hellobari','{\"settings\":{\"featured_properties_title\":{\"old_value\":null,\"new_value\":\"Latest Properties\"},\"featured_properties_des\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"},\"featured_properties_btn_title\":{\"old_value\":null,\"new_value\":\"View All Properties\"}}}','1','2021-02-23 03:43:49','2021-02-23 03:46:23'),(63,'counter','hellobari','{\"settings\":{\"counter_bg_img\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-02-22-6033df6368137.jpg\"}},\"content\":{\"counter_first_section\":{\"counter_first_section_title\":{\"old_value\":null,\"new_value\":\"Total Agents\"},\"counter_first_section_count\":{\"old_value\":null,\"new_value\":\"880\"}},\"counter_second_section\":{\"counter_second_section_title\":{\"old_value\":null,\"new_value\":\"Total Sales\"},\"counter_second_section_count\":{\"old_value\":null,\"new_value\":\"1798\"}},\"counter_third_section\":{\"counter_third_section_title\":{\"old_value\":null,\"new_value\":\"Total Projects\"},\"counter_third_section_count\":{\"old_value\":null,\"new_value\":\"582\"}},\"counter_four_section\":{\"counter_four_section_title\":{\"old_value\":null,\"new_value\":\"Total Customers\"},\"counter_four_section_count\":{\"old_value\":null,\"new_value\":\"3698\"}}}}','1','2021-02-23 03:44:19','2021-02-23 03:46:23'),(64,'property_agents','hellobari','{\"settings\":{\"property_agent_title\":{\"old_value\":null,\"new_value\":\"Property Agents\"},\"property_agent_descrtiption\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"},\"property_agent_btn_title\":{\"old_value\":null,\"new_value\":\"View All Agents\"}}}','1','2021-02-23 03:44:38','2021-02-23 03:46:23'),(65,'find_city','hellobari','{\"settings\":{\"find_city_title\":{\"old_value\":null,\"new_value\":\"Find us in your city\"},\"find_city_des\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"}}}','1','2021-02-23 03:44:46','2021-02-23 03:46:23'),(66,'blog_list','hellobari','{\"settings\":{\"blog_list_title\":{\"old_value\":null,\"new_value\":\"Latest Blogs\"},\"blog_list_des\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"},\"blog_list_btn_title\":{\"old_value\":null,\"new_value\":\"View All Blogs\"}}}','1','2021-02-23 03:44:53','2021-02-23 03:46:23'),(67,'footer','hellobari','{\"settings\":{\"footer_image\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-02-22-6033df938d691.png\"},\"footer_des\":{\"old_value\":null,\"new_value\":\"Lorem ipsum dolor sit amet, consect etur adi pisicing elit sed do eiusmod tempor incididunt ut labore.\"},\"footer_copyright\":{\"old_value\":null,\"new_value\":\"Copyright \\u00a9 Website - 2021. Design By Amcoders\"}},\"content\":{\"\":{\"social_facebook_link\":{\"old_value\":null,\"new_value\":\"#\"},\"social_twitter_link\":{\"old_value\":null,\"new_value\":\"#\"},\"social_google_link\":{\"old_value\":null,\"new_value\":\"#\"},\"social_instagram_link\":{\"old_value\":null,\"new_value\":\"#\"},\"social_pinterest_link\":{\"old_value\":null,\"new_value\":\"#\"}},\"footer_right\":{\"footer_right_title\":{\"old_value\":null,\"new_value\":\"Newsletter\"},\"footer_right_des\":{\"old_value\":null,\"new_value\":\"88 Broklyn Golden Street, New York. USA needhelp@ziston.com\"},\"footer_right_btn_title\":{\"old_value\":null,\"new_value\":\"Subscribe\"}}}}','1','2021-02-23 03:45:07','2021-02-23 03:46:23'),(68,'header','mamabari','{\"settings\":{\"header_phone_number\":{\"old_value\":\"4354354364443\",\"new_value\":\"4354354364443\"},\"header_email_address\":{\"old_value\":\"support@amcoders.com\",\"new_value\":\"support@amcoders.com\"},\"logo\":{\"old_value\":\"uploads\\/2021-02-24-6035d10068988.png\",\"new_value\":\"uploads\\/2021-02-24-6035d17d6913b.png\"},\"header_signin_title\":{\"old_value\":\"Sign In\",\"new_value\":\"Sign In\"},\"header_create_property_title\":{\"old_value\":\"Create Property\",\"new_value\":\"Create Property\"}}}','1','2021-02-24 15:07:21','2021-02-24 15:09:39'),(69,'hero','mamabari','{\"settings\":{\"hero_bg_img\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-02-24-6035d1a278a47.jpg\"},\"hero_title\":{\"old_value\":null,\"new_value\":\"Do More With Jomidar\"}}}','1','2021-02-24 15:10:10','2021-02-24 15:10:35'),(70,'property_agents','mamabari','{\"settings\":{\"property_agent_title\":{\"old_value\":null,\"new_value\":\"Property Agents\"},\"property_agent_descrtiption\":{\"old_value\":null,\"new_value\":\"Proportioned interiors Club over 10,000 square feet\"},\"property_agent_btn_title\":{\"old_value\":null,\"new_value\":\"View All Agents\"}}}','1','2021-02-24 15:11:28','2021-02-24 15:11:42'),(71,'featured_properties','mamabari','{\"settings\":{\"featured_properties_title\":{\"old_value\":null,\"new_value\":\"Latest Properties\"},\"featured_properties_des\":{\"old_value\":null,\"new_value\":\"Proportioned interiors Club over 10,000 square feet\"},\"featured_properties_btn_title\":{\"old_value\":null,\"new_value\":\"View All Properties\"}}}','1','2021-02-24 15:12:03','2021-02-24 15:12:10'),(72,'find_city','mamabari','{\"settings\":{\"find_city_bg_img\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-02-24-6035d2227c1c2.jpg\"},\"find_city_title\":{\"old_value\":null,\"new_value\":\"Find us in your city\"},\"find_city_des\":{\"old_value\":null,\"new_value\":\"Proportioned interiors Club over 10,000 square feet\"}}}','1','2021-02-24 15:12:18','2021-02-24 15:12:26'),(73,'blog_list','mamabari','{\"settings\":{\"blog_list_title\":{\"old_value\":null,\"new_value\":\"Latest Blogs\"},\"blog_list_des\":{\"old_value\":null,\"new_value\":\"Proportioned interiors Club over 10,000 square feet\"},\"blog_list_btn_title\":{\"old_value\":null,\"new_value\":\"View All Blogs\"}}}','1','2021-02-24 15:12:42','2021-02-24 15:12:49'),(74,'footer','mamabari','{\"settings\":{\"footer_image\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-02-24-6035d24c0e1bd.png\"},\"footer_des\":{\"old_value\":null,\"new_value\":\"Lorem ipsum dolor sit amet, consect etur adi pisicing elit sed do eiusmod tempor incididunt ut labore.\"},\"footer_copyright\":{\"old_value\":null,\"new_value\":\"Copyright \\u00a9 Website - 2021. Design By Amcoders\"}},\"content\":{\"footer_right\":{\"footer_right_title\":{\"old_value\":null,\"new_value\":\"Newsletter\"},\"footer_right_des\":{\"old_value\":null,\"new_value\":\"88 Broklyn Golden Street, New York. USA needhelp@ziston.com\"},\"footer_right_btn_title\":{\"old_value\":null,\"new_value\":\"Subscribe\"}}}}','1','2021-02-24 15:13:00','2021-02-24 15:13:29'),(75,'header','nanabari','{\"settings\":{\"header_phone_number\":{\"old_value\":null,\"new_value\":\"4354354364443\"},\"header_email_address\":{\"old_value\":null,\"new_value\":\"support@amcoders.com\"},\"logo\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-02-24-60367a3f9b2d1.png\"},\"header_signin_title\":{\"old_value\":null,\"new_value\":\"Sign In\"},\"header_create_property_title\":{\"old_value\":null,\"new_value\":\"Create Property\"}}}','1','2021-02-25 03:09:05','2021-02-25 03:09:42'),(76,'property_agents','nanabari','{\"settings\":{\"property_agent_title\":{\"old_value\":null,\"new_value\":\"Property Agents\"},\"property_agent_descrtiption\":{\"old_value\":null,\"new_value\":\"Proportioned interiors Club over 10,000 square feet\"},\"property_agent_btn_title\":{\"old_value\":null,\"new_value\":\"View All Agents\"}}}','1','2021-02-25 03:09:49','2021-02-25 03:10:39'),(77,'featured_properties','nanabari','{\"settings\":{\"featured_properties_title\":{\"old_value\":null,\"new_value\":\"Latest Properties\"},\"featured_properties_des\":{\"old_value\":null,\"new_value\":\"Proportioned interiors Club over 10,000 square feet\"},\"featured_properties_btn_title\":{\"old_value\":null,\"new_value\":\"View All Properties\"}}}','1','2021-02-25 03:10:12','2021-02-25 03:10:39'),(78,'find_city','nanabari','{\"settings\":{\"find_city_bg_img\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-02-24-60367a71f15ca.jpg\"},\"find_city_title\":{\"old_value\":null,\"new_value\":\"Find us in your city\"},\"find_city_des\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"}}}','1','2021-02-25 03:10:26','2021-02-25 03:10:39'),(79,'blog_list','nanabari','{\"settings\":{\"blog_list_title\":{\"old_value\":null,\"new_value\":\"Latest Blogs\"},\"blog_list_des\":{\"old_value\":null,\"new_value\":\"Handpicked Exclusive Properties By Our Team.\"},\"blog_list_btn_title\":{\"old_value\":null,\"new_value\":\"View All Blogs\"}}}','1','2021-02-25 03:10:44','2021-02-25 03:10:50'),(80,'footer','nanabari','{\"settings\":{\"footer_image\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-02-24-60367a95a935c.png\"},\"footer_des\":{\"old_value\":null,\"new_value\":\"Lorem ipsum dolor sit amet, consect etur adi pisicing elit sed do eiusmod tempor incididunt ut labore.\"},\"footer_copyright\":{\"old_value\":null,\"new_value\":\"Copyright \\u00a9 Website - 2021. Design By Amcoders\"}},\"content\":{\"footer_right\":{\"footer_right_title\":{\"old_value\":null,\"new_value\":\"Newsletter\"},\"footer_right_des\":{\"old_value\":null,\"new_value\":\"88 Broklyn Golden Street, New York. USA needhelp@ziston.com\"},\"footer_right_btn_title\":{\"old_value\":null,\"new_value\":\"Subscribe\"}}}}','1','2021-02-25 03:11:01','2021-02-25 03:11:23'),(81,'header','tomarbari','{\"settings\":{\"header_phone_number\":{\"old_value\":null,\"new_value\":\"+880-258-5874\"},\"header_email_address\":{\"old_value\":null,\"new_value\":\"support@amcoders.com\"},\"logo\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-02-28-603ba542585db.png\"},\"header_signin_title\":{\"old_value\":null,\"new_value\":\"Sign In\"},\"header_create_property_title\":{\"old_value\":null,\"new_value\":\"Create Property\"}}}','1','2021-03-01 01:13:59','2021-03-01 01:14:59'),(82,'footer','tomarbari','{\"settings\":{\"footer_image\":{\"old_value\":null,\"new_value\":\"uploads\\/2021-02-28-603ba56bb156d.png\"},\"footer_des\":{\"old_value\":null,\"new_value\":\"Lorem ipsum dolor sit amet, consect etur adi pisicing elit sed do eiusmod tempor incididunt ut labore.\"},\"footer_copyright\":{\"old_value\":null,\"new_value\":\"Copyright \\u00a9 Website - 2021. Design By Amcoders\"}},\"content\":{\"footer_right\":{\"footer_right_title\":{\"old_value\":null,\"new_value\":\"Newsletter\"},\"footer_right_des\":{\"old_value\":null,\"new_value\":\"88 Broklyn Golden Street, New York. USA needhelp@ziston.com\"},\"footer_right_btn_title\":{\"old_value\":null,\"new_value\":\"Subscribe\"}}}}','1','2021-03-01 01:15:07','2021-03-01 01:16:06');
/*!40000 ALTER TABLE `customizers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mediaposts`
--

DROP TABLE IF EXISTS `mediaposts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mediaposts` (
  `term_id` bigint(20) unsigned NOT NULL,
  `media_id` bigint(20) unsigned NOT NULL,
  KEY `mediaposts_term_id_foreign` (`term_id`),
  KEY `mediaposts_media_id_foreign` (`media_id`),
  CONSTRAINT `mediaposts_media_id_foreign` FOREIGN KEY (`media_id`) REFERENCES `medias` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mediaposts_term_id_foreign` FOREIGN KEY (`term_id`) REFERENCES `terms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mediaposts`
--

LOCK TABLES `mediaposts` WRITE;
/*!40000 ALTER TABLE `mediaposts` DISABLE KEYS */;
INSERT INTO `mediaposts` (`term_id`, `media_id`) VALUES (5,1),(5,2),(5,3),(5,4),(5,6),(5,5),(6,11),(6,10),(6,12),(6,13),(7,14),(7,15),(7,16),(7,17);
/*!40000 ALTER TABLE `mediaposts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medias`
--

DROP TABLE IF EXISTS `medias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medias` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `medias_user_id_foreign` (`user_id`),
  CONSTRAINT `medias_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medias`
--

LOCK TABLES `medias` WRITE;
/*!40000 ALTER TABLE `medias` DISABLE KEYS */;
INSERT INTO `medias` (`id`, `name`, `type`, `url`, `size`, `path`, `user_id`, `created_at`, `updated_at`) VALUES (1,'uploads/21/01/10012116103007215ffb3d3126706.webp','jpg','http://realestate.avanteca.com.bd/uploads/21/01/10012116103007215ffb3d3126706.webp','32184kib','uploads/21/01/',4,'2021-01-10 22:45:21','2021-01-10 22:45:21'),(2,'uploads/21/01/10012116103007215ffb3d3125675.webp','jpg','http://realestate.avanteca.com.bd/uploads/21/01/10012116103007215ffb3d3125675.webp','51716kib','uploads/21/01/',4,'2021-01-10 22:45:21','2021-01-10 22:45:21'),(3,'uploads/21/01/10012116103007225ffb3d323297d.webp','jpg','http://realestate.avanteca.com.bd/uploads/21/01/10012116103007225ffb3d323297d.webp','22288kib','uploads/21/01/',4,'2021-01-10 22:45:22','2021-01-10 22:45:22'),(4,'uploads/21/01/10012116103007225ffb3d322e80e.webp','jpg','http://realestate.avanteca.com.bd/uploads/21/01/10012116103007225ffb3d322e80e.webp','43584kib','uploads/21/01/',4,'2021-01-10 22:45:22','2021-01-10 22:45:22'),(5,'uploads/21/01/10012116103007225ffb3d32f1e81.webp','jpg','http://realestate.avanteca.com.bd/uploads/21/01/10012116103007225ffb3d32f1e81.webp','34844kib','uploads/21/01/',4,'2021-01-10 22:45:23','2021-01-10 22:45:23'),(6,'uploads/21/01/10012116103007225ffb3d32e8548.webp','jpg','http://realestate.avanteca.com.bd/uploads/21/01/10012116103007225ffb3d32e8548.webp','39370kib','uploads/21/01/',4,'2021-01-10 22:45:23','2021-01-10 22:45:23'),(7,'uploads/21/01/11012116103399535ffbd67132cff.webp','png','http://realestate.avanteca.com.bd/uploads/21/01/11012116103399535ffbd67132cff.webp','326kib','uploads/21/01/',1,'2021-01-11 09:39:13','2021-01-11 09:39:13'),(8,'uploads/21/01/11012116103399535ffbd671f06e5.webp','png','http://realestate.avanteca.com.bd/uploads/21/01/11012116103399535ffbd671f06e5.webp','364kib','uploads/21/01/',1,'2021-01-11 09:39:14','2021-01-11 09:39:14'),(9,'uploads/21/01/11012116103399545ffbd672163c9.webp','png','http://realestate.avanteca.com.bd/uploads/21/01/11012116103399545ffbd672163c9.webp','282kib','uploads/21/01/',1,'2021-01-11 09:39:14','2021-01-11 09:39:14'),(10,'uploads/21/01/11012116103578055ffc1c2dee004.webp','jpg','http://realestate.avanteca.com.bd/uploads/21/01/11012116103578055ffc1c2dee004.webp','34844kib','uploads/21/01/',3,'2021-01-11 14:36:47','2021-01-11 14:36:47'),(11,'uploads/21/01/11012116103578055ffc1c2dee356.webp','jpg','http://realestate.avanteca.com.bd/uploads/21/01/11012116103578055ffc1c2dee356.webp','39370kib','uploads/21/01/',3,'2021-01-11 14:36:47','2021-01-11 14:36:47'),(12,'uploads/21/01/11012116103578085ffc1c30c8af4.webp','jpg','http://realestate.avanteca.com.bd/uploads/21/01/11012116103578085ffc1c30c8af4.webp','10636kib','uploads/21/01/',3,'2021-01-11 14:36:49','2021-01-11 14:36:49'),(13,'uploads/21/01/11012116103578085ffc1c30cc21f.webp','jpg','http://realestate.avanteca.com.bd/uploads/21/01/11012116103578085ffc1c30cc21f.webp','56598kib','uploads/21/01/',3,'2021-01-11 14:36:49','2021-01-11 14:36:49'),(14,'uploads/21/01/11012116103582515ffc1deba3f0f.webp','jpg','http://realestate.avanteca.com.bd/uploads/21/01/11012116103582515ffc1deba3f0f.webp','36756kib','uploads/21/01/',2,'2021-01-11 14:44:12','2021-01-11 14:44:12'),(15,'uploads/21/01/11012116103582575ffc1df1cce75.webp','jpg','http://realestate.avanteca.com.bd/uploads/21/01/11012116103582575ffc1df1cce75.webp','24038kib','uploads/21/01/',2,'2021-01-11 14:44:18','2021-01-11 14:44:18'),(16,'uploads/21/01/11012116103582645ffc1df8df1eb.webp','jpg','http://realestate.avanteca.com.bd/uploads/21/01/11012116103582645ffc1df8df1eb.webp','56598kib','uploads/21/01/',2,'2021-01-11 14:44:25','2021-01-11 14:44:25'),(17,'uploads/21/01/11012116103582715ffc1dff3d930.webp','jpg','http://realestate.avanteca.com.bd/uploads/21/01/11012116103582715ffc1dff3d930.webp','51716kib','uploads/21/01/',2,'2021-01-11 14:44:31','2021-01-11 14:44:31'),(18,'uploads/2021-06-08-60bfd60ad974c.png','png','//realestate.avanteca.com.bd/uploads/2021-06-08-60bfd60ad974c.png','5112kib','uploads/',1,'2021-06-09 00:41:46','2021-06-09 00:41:46'),(19,'uploads/2021-06-08-60bfd753ad190.png','png','//realestate.avanteca.com.bd/uploads/2021-06-08-60bfd753ad190.png','5112kib','uploads/',1,'2021-06-09 00:47:15','2021-06-09 00:47:15');
/*!40000 ALTER TABLE `medias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `lang` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` (`id`, `name`, `position`, `data`, `lang`, `status`, `created_at`, `updated_at`) VALUES (1,'Main Menu','Header','[{\"text\":\"Home\",\"icon\":\"\",\"href\":\"/\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"Property\",\"icon\":\"empty\",\"href\":\"#\",\"target\":\"_self\",\"title\":\"\",\"children\":[{\"text\":\"Property List\",\"icon\":\"empty\",\"href\":\"/list\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"Property Map\",\"icon\":\"empty\",\"href\":\"/map\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"Property Details\",\"icon\":\"empty\",\"href\":\"/list\",\"target\":\"_self\",\"title\":\"\"}]},{\"text\":\"Project\",\"icon\":\"empty\",\"href\":\"#\",\"target\":\"_self\",\"title\":\"\",\"children\":[{\"text\":\"Projects\",\"icon\":\"empty\",\"href\":\"/project\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"Project detail\",\"icon\":\"empty\",\"href\":\"/project\",\"target\":\"_self\",\"title\":\"\"}]},{\"text\":\"Agent\",\"icon\":\"empty\",\"href\":\"#\",\"target\":\"_self\",\"title\":\"\",\"children\":[{\"text\":\"Agents\",\"icon\":\"empty\",\"href\":\"/agent/list\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"Agent Details\",\"icon\":\"empty\",\"href\":\"/agent/list\",\"target\":\"_self\",\"title\":\"\"}]},{\"text\":\"Agency\",\"icon\":\"empty\",\"href\":\"#\",\"target\":\"_self\",\"title\":\"\",\"children\":[{\"text\":\"Agencies\",\"icon\":\"empty\",\"href\":\"/agency/list\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"Agency Detail\",\"icon\":\"empty\",\"href\":\"/agency/list\",\"target\":\"_self\",\"title\":\"\"}]},{\"text\":\"Blog\",\"icon\":\"empty\",\"href\":\"#\",\"target\":\"_self\",\"title\":\"\",\"children\":[{\"text\":\"Blogs\",\"icon\":\"empty\",\"href\":\"/blogs\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"Blog Details\",\"icon\":\"empty\",\"href\":\"/blogs\",\"target\":\"_self\",\"title\":\"\"}]},{\"text\":\"Contact\",\"icon\":\"empty\",\"href\":\"/contact\",\"target\":\"_self\",\"title\":\"\"}]','en',1,'2021-01-19 01:39:58','2021-01-19 17:30:20'),(5,'Main Menu','Header','[{\"text\":\"الصفحة الرئيسية\",\"href\":\"/\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"خاصية\",\"href\":\"#\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\",\"children\":[{\"text\":\"قائمة الممتلكات\",\"href\":\"/list\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"خريطة الملكية\",\"href\":\"/map\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"تفاصيل اوضح\",\"href\":\"/list\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"}]},{\"text\":\"مشروع\",\"href\":\"#\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\",\"children\":[{\"text\":\"المشاريع\",\"href\":\"/project\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"تفاصيل المشروع\",\"href\":\"/project\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"}]},{\"text\":\"وكيل\",\"href\":\"#\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\",\"children\":[{\"text\":\"عملاء\",\"href\":\"/agent/list\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"تفاصيل الوكيل\",\"href\":\"/agent/list\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"}]},{\"text\":\"وكالة\",\"href\":\"#\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\",\"children\":[{\"text\":\"وكالات\",\"href\":\"/agency/list\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"تفاصيل الوكالة\",\"href\":\"/agency/list\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"}]},{\"text\":\"مدونة\",\"href\":\"#\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\",\"children\":[{\"text\":\"المدونات\",\"href\":\"/blogs\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"تفاصيل المدونة\",\"href\":\"/blogs\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"}]},{\"text\":\"اتصل\",\"href\":\"/contact\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"}]','ar',1,'2021-01-19 01:39:58','2021-01-19 17:50:26'),(6,'Explore','Footer_left','[{\"text\":\"About Us\",\"icon\":\"\",\"href\":\"/page/about-us\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"My Account\",\"icon\":\"empty\",\"href\":\"/agent/dashboard\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"My Listings\",\"icon\":\"empty\",\"href\":\"/agent/property\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"Pricing Packages\",\"icon\":\"empty\",\"href\":\"/agent/package\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"User Dashboard\",\"icon\":\"empty\",\"href\":\"/agent/dashboard\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"Bookmarks\",\"icon\":\"empty\",\"href\":\"/agent/favourites\",\"target\":\"_self\",\"title\":\"\"}]','en',1,'2021-01-21 00:59:56','2021-01-21 01:06:22'),(7,'About','Footer_right','[{\"text\":\"Sitemap\",\"href\":\"/sitemap.xml\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"Contact Us\",\"href\":\"/contact\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"Terms And Condition\",\"href\":\"/page/terms-and-condition\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"Privacy Policy\",\"href\":\"/page/privacy-policy\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"Latest News\",\"href\":\"/blog\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"Support\",\"href\":\"/contact\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"}]','en',1,'2021-01-21 01:23:41','2021-06-09 00:33:50'),(8,'حول','Footer_right','[{\"text\":\"خريطة الموقع\",\"href\":\"/sitemap.xml\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"اتصل بنا\",\"href\":\"/contact\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"أحكام وشروط\",\"href\":\"/page/terms-and-condition\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"سياسة الخصوصية\",\"href\":\"/page/privacy-policy\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"أحدث الأخبار\",\"href\":\"/blog\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"الدعم\",\"href\":\"/contact\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"}]','ar',1,'2021-01-21 01:23:41','2021-01-21 04:04:23'),(9,'يكتشف','Footer_left','[{\"text\":\"معلومات عنا\",\"href\":\"/page/about-us\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"حسابي\",\"href\":\"/agent/dashboard\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"القوائم الخاصة بي\",\"href\":\"/agent/property\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"حزم التسعير\",\"href\":\"/agent/package\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"لوحة تحكم المستخدم\",\"href\":\"/agent/dashboard\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"},{\"text\":\"إشارات مرجعية\",\"href\":\"/agent/favourites\",\"icon\":\"empty\",\"target\":\"_self\",\"title\":\"\"}]','ar',1,'2021-01-21 00:59:56','2021-01-21 04:12:31');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meta`
--

DROP TABLE IF EXISTS `meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'excerpt',
  `content` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `meta_term_id_foreign` (`term_id`),
  CONSTRAINT `meta_term_id_foreign` FOREIGN KEY (`term_id`) REFERENCES `terms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meta`
--

LOCK TABLES `meta` WRITE;
/*!40000 ALTER TABLE `meta` DISABLE KEYS */;
INSERT INTO `meta` (`id`, `term_id`, `type`, `content`) VALUES (1,5,'excerpt','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),(2,5,'content','<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n        \r\n        <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>'),(3,5,'contact_type','{\"contact_type\":\"mail\",\"email\":\"mahi@mailinator.com\"}'),(4,5,'youtube_url','wv7_0DtIQps'),(5,5,'virtual_tour','https://my.matterport.com/show/?m=CrZgGg34uFa'),(6,5,'floor_plan','{\"file_name\":\"uploads\\/21\\/01\\/16103007701610300770.jpg\",\"name\":\"First Floor\",\"square_ft\":\"25\"}'),(7,5,'floor_plan','{\"file_name\":\"uploads\\/21\\/01\\/16103008831610300883.jpg\",\"name\":\"Second Floor\",\"square_ft\":\"65\"}'),(8,5,'floor_plan','{\"file_name\":\"uploads\\/21\\/01\\/16103009011610300901.jpg\",\"name\":\"Third Floor\",\"square_ft\":\"87\"}'),(9,6,'excerpt','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),(10,6,'content','<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n        \r\n        <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>'),(11,6,'contact_type','{\"contact_type\":\"mail\",\"email\":\"gaqoq@mailinator.com\"}'),(12,6,'youtube_url','wv7_0DtIQps'),(13,6,'virtual_tour','https://my.matterport.com/show/?m=CrZgGg34uFa'),(14,6,'floor_plan','{\"file_name\":\"uploads\\/21\\/01\\/16103578331610357833.jpg\",\"name\":\"First Floor\",\"square_ft\":\"23\"}'),(15,6,'floor_plan','{\"file_name\":\"uploads\\/21\\/01\\/16103578471610357847.jpg\",\"name\":\"Second Floor\",\"square_ft\":\"54\"}'),(16,7,'excerpt','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),(17,7,'content','<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n        \r\n        <p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>'),(18,7,'contact_type','{\"contact_type\":\"mail\",\"email\":\"sicequb@mailinator.com\"}'),(19,7,'youtube_url','wv7_0DtIQps'),(20,7,'virtual_tour','https://my.matterport.com/show/?m=CrZgGg34uFa'),(21,7,'floor_plan','{\"file_name\":\"uploads\\/21\\/01\\/16103582891610358289.jpg\",\"name\":\"First Floor\",\"square_ft\":\"43\"}'),(22,7,'floor_plan','{\"file_name\":\"uploads\\/21\\/01\\/16103584251610358425.jpg\",\"name\":\"Second Floor\",\"square_ft\":\"67\"}'),(23,8,'excerpt','Real estate festival is one of the famous feval for explain to you how all this mistaolt deand praising pain wasnad I will give complete'),(24,8,'preview','http://realestate.avanteca.com.bd/uploads/21/01/11012116103624465ffc2e4ed8262.webp'),(25,8,'content','<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n    \r\n    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>'),(26,9,'excerpt','Real estate festival is one of the famous feval for explain to you how all this mistaolt deand praising pain wasnad I will give complete'),(27,9,'preview','http://realestate.avanteca.com.bd/uploads/21/01/11012116103624555ffc2e5734666.webp'),(28,9,'content','<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n    \r\n    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>'),(29,10,'excerpt','Real estate festival is one of the famous feval for explain to you how all this mistaolt deand praising pain wasnad I will give complete'),(30,10,'preview','http://realestate.avanteca.com.bd/uploads/21/01/11012116103624545ffc2e56c0aa5.webp'),(31,10,'content','<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n    \r\n    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>'),(32,11,'excerpt','This is about us page'),(33,11,'content','This is about us page'),(34,12,'excerpt','Sitemap'),(35,12,'content','Sitemap'),(36,13,'excerpt','Terms And Condition'),(37,13,'content','Terms And Condition'),(38,14,'excerpt','Privacy Policy'),(39,14,'content','Privacy Policy'),(40,15,'excerpt','Latest News'),(41,15,'content','Latest News'),(42,16,'excerpt','Blog'),(43,16,'content','Blog'),(44,17,'excerpt',''),(45,17,'content',''),(46,17,'seo','{\"meta_title\":\"Demo\",\"meta_tags\":\"\",\"meta_description\":\"\"}'),(47,17,'contact_type','{\"email\":\"admin@admin.com\",\"contact_type\":\"mail\"}');
/*!40000 ALTER TABLE `meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2014_10_12_200000_add_two_factor_columns_to_users_table',1),(4,'2019_08_19_000000_create_failed_jobs_table',1),(5,'2019_12_14_000001_create_personal_access_tokens_table',1),(6,'2020_02_24_073339_create_medias_table',1),(7,'2020_02_24_073655_create_categories_table',1),(8,'2020_02_24_094503_create_menu_table',1),(9,'2020_04_13_142641_create_options_table',1),(10,'2020_04_13_144019_create_terms_table',1),(11,'2020_04_13_144038_create_meta_table',1),(12,'2020_04_13_144625_create_post_category_table',1),(13,'2020_04_16_110534_create_customizers_table',1),(14,'2020_06_13_060141_create_user_meta_table',1),(15,'2020_08_24_062655_create_categorymetas_table',1),(16,'2020_10_24_101523_create_sessions_table',1),(17,'2020_10_24_110433_create_permission_tables',1),(18,'2020_10_29_145642_create_mediaposts_table',1),(19,'2020_10_29_152641_create_categoryusers_table',1),(20,'2020_10_31_074524_create_categoryrelations_table',1),(21,'2020_11_03_145224_create_postcategoryoptions_table',1),(22,'2020_11_14_083753_create_termrelations_table',1),(23,'2020_12_05_135234_create_prices_table',1),(24,'2020_12_07_084540_create_reviews_table',1),(25,'2020_12_07_171004_create_transactions_table',1),(26,'2021_01_03_133141_create_terms_user_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES (1,'App\\Models\\User',1);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `options`
--

DROP TABLE IF EXISTS `options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `options` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `options`
--

LOCK TABLES `options` WRITE;
/*!40000 ALTER TABLE `options` DISABLE KEYS */;
INSERT INTO `options` (`id`, `key`, `value`, `created_at`, `updated_at`) VALUES (1,'theme_data','{\"theme_color\":\"#9cc25d\",\"socials\":[{\"icon\":\"fa fa-pinterest-p\",\"url\":\"#\"},{\"icon\":\"fa fa-pinterest-p\",\"url\":\"#\"},{\"icon\":\"fa fa-instagram\",\"url\":\"#\"},{\"icon\":\"fa fa-twitter\",\"url\":\"#\"}],\"back_to_top\":\"enable\"}','2021-06-09 00:19:34','2021-06-09 00:19:34'),(2,'seo','{\"title\":\"LPress\",\"description\":null,\"canonical\":null,\"tags\":null,\"twitterTitle\":null}','2021-06-09 00:19:34','2021-06-09 00:19:34'),(3,'langlist','{\"English\":\"en\",\"Malay\":\"bn\"}','2021-06-09 00:19:34','2021-06-09 00:19:34'),(4,'default_lat_long','{\"latitude\":\"23.8103\",\"longitude\":\"90.4125\",\"zoom\":\"10\"}','2021-06-09 00:19:34','2021-06-09 00:19:34'),(5,'lp_filesystem','{\"compress\":5,\"system_type\":\"local\",\"system_url\":null}','2021-06-09 00:19:34','2021-06-09 00:19:34'),(6,'payment_settings','{\"currency_name\":\"USD\",\"currency_icon\":\"$\",\"currency_position\":\"left\"}','2021-06-09 00:19:34','2021-06-09 00:19:34'),(7,'breadcrumb','http://realestate.avanteca.com.bd/uploads/21/01/11012116103582515ffc1deba3f0f.webp','2021-01-21 17:01:43','2021-01-22 04:35:59'),(8,'theme_color','#2f915e','2021-01-22 04:30:07','2021-06-09 00:49:32'),(9,'listing_page','without_map','2021-01-23 15:46:37','2021-01-23 15:51:44');
/*!40000 ALTER TABLE `options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `group_name`, `created_at`, `updated_at`) VALUES (1,'dashboard','web','dashboard','2021-06-09 00:19:31','2021-06-09 00:19:31'),(2,'admin.create','web','admin','2021-06-09 00:19:31','2021-06-09 00:19:31'),(3,'admin.edit','web','admin','2021-06-09 00:19:31','2021-06-09 00:19:31'),(4,'admin.update','web','admin','2021-06-09 00:19:31','2021-06-09 00:19:31'),(5,'admin.delete','web','admin','2021-06-09 00:19:31','2021-06-09 00:19:31'),(6,'admin.list','web','admin','2021-06-09 00:19:31','2021-06-09 00:19:31'),(7,'role.create','web','role','2021-06-09 00:19:31','2021-06-09 00:19:31'),(8,'role.edit','web','role','2021-06-09 00:19:31','2021-06-09 00:19:31'),(9,'role.update','web','role','2021-06-09 00:19:31','2021-06-09 00:19:31'),(10,'role.delete','web','role','2021-06-09 00:19:31','2021-06-09 00:19:31'),(11,'role.list','web','role','2021-06-09 00:19:31','2021-06-09 00:19:31'),(12,'media.list','web','media','2021-06-09 00:19:31','2021-06-09 00:19:31'),(13,'media.upload','web','media','2021-06-09 00:19:31','2021-06-09 00:19:31'),(14,'media.delete','web','media','2021-06-09 00:19:31','2021-06-09 00:19:31'),(15,'page.create','web','Pages','2021-06-09 00:19:31','2021-06-09 00:19:31'),(16,'page.edit','web','Pages','2021-06-09 00:19:31','2021-06-09 00:19:31'),(17,'page.delete','web','Pages','2021-06-09 00:19:31','2021-06-09 00:19:31'),(18,'page.list','web','Pages','2021-06-09 00:19:32','2021-06-09 00:19:32'),(19,'blog.create','web','Blogs','2021-06-09 00:19:32','2021-06-09 00:19:32'),(20,'blog.edit','web','Blogs','2021-06-09 00:19:32','2021-06-09 00:19:32'),(21,'blog.delete','web','Blogs','2021-06-09 00:19:32','2021-06-09 00:19:32'),(22,'blog.list','web','Blogs','2021-06-09 00:19:32','2021-06-09 00:19:32'),(23,'system.settings','web','Developer','2021-06-09 00:19:32','2021-06-09 00:19:32'),(24,'theme.option','web','Appearance','2021-06-09 00:19:32','2021-06-09 00:19:32'),(25,'theme','web','Appearance','2021-06-09 00:19:32','2021-06-09 00:19:32'),(26,'menu','web','Appearance','2021-06-09 00:19:32','2021-06-09 00:19:32'),(27,'seo','web','settings','2021-06-09 00:19:32','2021-06-09 00:19:32'),(28,'filesystem','web','settings','2021-06-09 00:19:32','2021-06-09 00:19:32'),(29,'backup','web','settings','2021-06-09 00:19:32','2021-06-09 00:19:32'),(30,'language_edit','web','language','2021-06-09 00:19:32','2021-06-09 00:19:32'),(31,'states.list','web','Location','2021-06-09 00:19:32','2021-06-09 00:19:32'),(32,'states.create','web','Location','2021-06-09 00:19:32','2021-06-09 00:19:32'),(33,'states.edit','web','Location','2021-06-09 00:19:32','2021-06-09 00:19:32'),(34,'cities.list','web','Location','2021-06-09 00:19:32','2021-06-09 00:19:32'),(35,'cities.create','web','Location','2021-06-09 00:19:32','2021-06-09 00:19:32'),(36,'cities.edit','web','Location','2021-06-09 00:19:32','2021-06-09 00:19:32'),(37,'testimonial.list','web','Testimonials','2021-06-09 00:19:32','2021-06-09 00:19:32'),(38,'testimonial.create','web','Testimonials','2021-06-09 00:19:32','2021-06-09 00:19:32'),(39,'testimonial.edit','web','Testimonials','2021-06-09 00:19:32','2021-06-09 00:19:32'),(40,'testimonial.delete','web','Testimonials','2021-06-09 00:19:32','2021-06-09 00:19:32'),(41,'package.list','web','Package','2021-06-09 00:19:32','2021-06-09 00:19:32'),(42,'package.create','web','Package','2021-06-09 00:19:32','2021-06-09 00:19:32'),(43,'package.edit','web','Package','2021-06-09 00:19:32','2021-06-09 00:19:32'),(44,'package.delete','web','Package','2021-06-09 00:19:32','2021-06-09 00:19:32'),(45,'agency_package.list','web','Agency Package','2021-06-09 00:19:32','2021-06-09 00:19:32'),(46,'agency_package.create','web','Agency Package','2021-06-09 00:19:32','2021-06-09 00:19:32'),(47,'agency_package.edit','web','Agency Package','2021-06-09 00:19:32','2021-06-09 00:19:32'),(48,'agency_package.delete','web','Agency Package','2021-06-09 00:19:32','2021-06-09 00:19:32'),(49,'user.list','web','Agent & User','2021-06-09 00:19:32','2021-06-09 00:19:32'),(50,'user.create','web','Agent & User','2021-06-09 00:19:32','2021-06-09 00:19:32'),(51,'user.edit','web','Agent & User','2021-06-09 00:19:32','2021-06-09 00:19:32'),(52,'user.delete','web','Agent & User','2021-06-09 00:19:32','2021-06-09 00:19:32'),(53,'agency.list','web','Agency','2021-06-09 00:19:32','2021-06-09 00:19:32'),(54,'agency.create','web','Agency','2021-06-09 00:19:32','2021-06-09 00:19:32'),(55,'agency.edit','web','Agency','2021-06-09 00:19:33','2021-06-09 00:19:33'),(56,'agency.delete','web','Agency','2021-06-09 00:19:33','2021-06-09 00:19:33'),(57,'api_and_getway','web','Payment Method','2021-06-09 00:19:33','2021-06-09 00:19:33'),(58,'transactions','web','Payment Method','2021-06-09 00:19:33','2021-06-09 00:19:33'),(59,'payment.settings','web','Payment Method','2021-06-09 00:19:33','2021-06-09 00:19:33'),(60,'review.list','web','Review & Rattings','2021-06-09 00:19:33','2021-06-09 00:19:33'),(61,'review.delete','web','Review & Rattings','2021-06-09 00:19:33','2021-06-09 00:19:33'),(62,'Properties.list','web','Real state','2021-06-09 00:19:33','2021-06-09 00:19:33'),(63,'Properties.create','web','Real state','2021-06-09 00:19:33','2021-06-09 00:19:33'),(64,'Properties.edit','web','Real state','2021-06-09 00:19:33','2021-06-09 00:19:33'),(65,'Properties.delete','web','Real state','2021-06-09 00:19:33','2021-06-09 00:19:33'),(66,'project.list','web','Real state','2021-06-09 00:19:33','2021-06-09 00:19:33'),(67,'project.create','web','Real state','2021-06-09 00:19:33','2021-06-09 00:19:33'),(68,'project.edit','web','Real state','2021-06-09 00:19:33','2021-06-09 00:19:33'),(69,'project.delete','web','Real state','2021-06-09 00:19:33','2021-06-09 00:19:33'),(70,'feature.list','web','Real state','2021-06-09 00:19:33','2021-06-09 00:19:33'),(71,'feature.edit','web','Real state','2021-06-09 00:19:33','2021-06-09 00:19:33'),(72,'feature.create','web','Real state','2021-06-09 00:19:33','2021-06-09 00:19:33'),(73,'facilities.list','web','Real state','2021-06-09 00:19:33','2021-06-09 00:19:33'),(74,'facilities.create','web','Real state','2021-06-09 00:19:33','2021-06-09 00:19:33'),(75,'facilities.edit','web','Real state','2021-06-09 00:19:33','2021-06-09 00:19:33'),(76,'category.list','web','Real state','2021-06-09 00:19:33','2021-06-09 00:19:33'),(77,'category.create','web','Real state','2021-06-09 00:19:33','2021-06-09 00:19:33'),(78,'category.edit','web','Real state','2021-06-09 00:19:33','2021-06-09 00:19:33'),(79,'investor.list','web','Real state','2021-06-09 00:19:33','2021-06-09 00:19:33'),(80,'investor.create','web','Real state','2021-06-09 00:19:33','2021-06-09 00:19:33'),(81,'investor.edit','web','Real state','2021-06-09 00:19:33','2021-06-09 00:19:33'),(82,'currency.list','web','Real state','2021-06-09 00:19:34','2021-06-09 00:19:34'),(83,'currency.create','web','Real state','2021-06-09 00:19:34','2021-06-09 00:19:34'),(84,'currency.edit','web','Real state','2021-06-09 00:19:34','2021-06-09 00:19:34'),(85,'status.create','web','Real state','2021-06-09 00:19:34','2021-06-09 00:19:34'),(86,'status.edit','web','Real state','2021-06-09 00:19:34','2021-06-09 00:19:34'),(87,'status.delete','web','Real state','2021-06-09 00:19:34','2021-06-09 00:19:34'),(88,'status.list','web','Real state','2021-06-09 00:19:34','2021-06-09 00:19:34'),(89,'input.list','web','Real state','2021-06-09 00:19:34','2021-06-09 00:19:34'),(90,'input.create','web','Real state','2021-06-09 00:19:34','2021-06-09 00:19:34'),(91,'input.edit','web','Real state','2021-06-09 00:19:34','2021-06-09 00:19:34'),(92,'input.delete','web','Real state','2021-06-09 00:19:34','2021-06-09 00:19:34');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_category`
--

DROP TABLE IF EXISTS `post_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_category` (
  `term_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'category',
  KEY `post_category_term_id_foreign` (`term_id`),
  KEY `post_category_category_id_foreign` (`category_id`),
  CONSTRAINT `post_category_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `post_category_term_id_foreign` FOREIGN KEY (`term_id`) REFERENCES `terms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_category`
--

LOCK TABLES `post_category` WRITE;
/*!40000 ALTER TABLE `post_category` DISABLE KEYS */;
INSERT INTO `post_category` (`term_id`, `category_id`, `type`) VALUES (5,5,'category'),(6,1,'category'),(7,2,'category'),(7,35,'features'),(7,36,'features'),(7,37,'features'),(7,38,'features'),(7,39,'features'),(7,40,'features'),(7,29,'status'),(7,19,'state'),(6,35,'features'),(6,36,'features'),(6,37,'features'),(6,38,'features'),(6,39,'features'),(6,40,'features'),(6,27,'status'),(6,20,'state'),(5,35,'features'),(5,36,'features'),(5,37,'features'),(5,38,'features'),(5,39,'features'),(5,40,'features'),(5,26,'status'),(5,19,'state');
/*!40000 ALTER TABLE `post_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `postcategoryoptions`
--

DROP TABLE IF EXISTS `postcategoryoptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `postcategoryoptions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint(20) unsigned NOT NULL,
  `term_id` bigint(20) unsigned NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `postcategoryoptions_category_id_foreign` (`category_id`),
  KEY `postcategoryoptions_term_id_foreign` (`term_id`),
  CONSTRAINT `postcategoryoptions_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `postcategoryoptions_term_id_foreign` FOREIGN KEY (`term_id`) REFERENCES `terms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `postcategoryoptions`
--

LOCK TABLES `postcategoryoptions` WRITE;
/*!40000 ALTER TABLE `postcategoryoptions` DISABLE KEYS */;
INSERT INTO `postcategoryoptions` (`id`, `category_id`, `term_id`, `type`, `value`) VALUES (1,21,5,'city','Dhaka, Bangladesh'),(2,21,5,'latitude','23.810332'),(3,21,5,'longitude','90.4125181'),(31,24,6,'city','Cox\'s Bazar, Bangladesh'),(32,24,6,'latitude','21.4272283'),(33,24,6,'longitude','92.0058074'),(58,22,7,'city','Faridpur, Bangladesh'),(59,22,7,'latitude','23.6018691'),(60,22,7,'longitude','89.8333382'),(99,17,7,'options','12'),(100,16,7,'options','32'),(101,41,7,'facilities','10'),(102,42,7,'facilities','12'),(103,43,7,'facilities','5'),(104,44,7,'facilities','13'),(105,45,7,'facilities','12'),(106,46,7,'facilities','10'),(107,47,7,'facilities','8'),(108,48,7,'facilities','23'),(109,49,7,'facilities','10'),(110,50,7,'facilities','5'),(111,51,7,'facilities','23'),(124,17,6,'options','12'),(125,16,6,'options','10'),(126,41,6,'facilities','12'),(127,42,6,'facilities','31'),(128,43,6,'facilities','23'),(129,44,6,'facilities','34'),(130,45,6,'facilities','12'),(131,46,6,'facilities','10'),(132,47,6,'facilities','8'),(133,48,6,'facilities','10'),(134,49,6,'facilities','9'),(135,50,6,'facilities','10'),(136,51,6,'facilities','23'),(137,17,5,'options','2'),(138,16,5,'options','4'),(139,41,5,'facilities','12'),(140,42,5,'facilities','14'),(141,43,5,'facilities','23'),(142,44,5,'facilities','13'),(143,45,5,'facilities','16'),(144,45,5,'facilities','18'),(145,46,5,'facilities','10'),(146,47,5,'facilities','12'),(147,48,5,'facilities','8'),(148,49,5,'facilities','15'),(149,50,5,'facilities','10'),(150,51,5,'facilities','13');
/*!40000 ALTER TABLE `postcategoryoptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prices`
--

DROP TABLE IF EXISTS `prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL,
  `price` double DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'min_price',
  PRIMARY KEY (`id`),
  KEY `prices_term_id_foreign` (`term_id`),
  CONSTRAINT `prices_term_id_foreign` FOREIGN KEY (`term_id`) REFERENCES `terms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prices`
--

LOCK TABLES `prices` WRITE;
/*!40000 ALTER TABLE `prices` DISABLE KEYS */;
INSERT INTO `prices` (`id`, `term_id`, `price`, `type`) VALUES (1,5,55232,'min_price'),(2,5,99789,'max_price'),(3,6,79432,'min_price'),(4,6,123456,'max_price'),(5,7,55043,'min_price'),(6,7,82134,'max_price');
/*!40000 ALTER TABLE `prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reviews` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `review` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_reported` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reviews_term_id_foreign` (`term_id`),
  KEY `reviews_user_id_foreign` (`user_id`),
  CONSTRAINT `reviews_term_id_foreign` FOREIGN KEY (`term_id`) REFERENCES `terms` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1),(11,1),(12,1),(13,1),(14,1),(15,1),(16,1),(17,1),(18,1),(19,1),(20,1),(21,1),(22,1),(23,1),(24,1),(25,1),(26,1),(27,1),(28,1),(29,1),(30,1),(31,1),(32,1),(33,1),(34,1),(35,1),(36,1),(37,1),(38,1),(39,1),(40,1),(41,1),(42,1),(43,1),(44,1),(45,1),(46,1),(47,1),(48,1),(49,1),(50,1),(51,1),(52,1),(53,1),(54,1),(55,1),(56,1),(57,1),(58,1),(59,1),(60,1),(61,1),(62,1),(63,1),(64,1),(65,1),(66,1),(67,1),(68,1),(69,1),(70,1),(71,1),(72,1),(73,1),(74,1),(75,1),(76,1),(77,1),(78,1),(79,1),(80,1),(81,1),(82,1),(83,1),(84,1),(85,1),(86,1),(87,1),(88,1),(89,1),(90,1),(91,1),(92,1);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES (1,'superadmin','web','2021-06-09 00:19:31','2021-06-09 00:19:31');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `termrelations`
--

DROP TABLE IF EXISTS `termrelations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `termrelations` (
  `term_id` bigint(20) unsigned NOT NULL,
  `child_id` bigint(20) unsigned NOT NULL,
  KEY `termrelations_term_id_foreign` (`term_id`),
  KEY `termrelations_child_id_foreign` (`child_id`),
  CONSTRAINT `termrelations_child_id_foreign` FOREIGN KEY (`child_id`) REFERENCES `terms` (`id`) ON DELETE CASCADE,
  CONSTRAINT `termrelations_term_id_foreign` FOREIGN KEY (`term_id`) REFERENCES `terms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `termrelations`
--

LOCK TABLES `termrelations` WRITE;
/*!40000 ALTER TABLE `termrelations` DISABLE KEYS */;
/*!40000 ALTER TABLE `termrelations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `terms`
--

DROP TABLE IF EXISTS `terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `terms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `status` int(11) NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `count` double NOT NULL DEFAULT 0,
  `featured` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `terms_user_id_foreign` (`user_id`),
  CONSTRAINT `terms_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `terms`
--

LOCK TABLES `terms` WRITE;
/*!40000 ALTER TABLE `terms` DISABLE KEYS */;
INSERT INTO `terms` (`id`, `title`, `slug`, `user_id`, `status`, `type`, `count`, `featured`, `created_at`, `updated_at`) VALUES (1,'Basic','basic',1,1,'package',5,23,'2021-01-10 22:35:03','2021-01-10 22:35:03'),(2,'Premium','premium',1,1,'package',20,50,'2021-01-10 22:35:28','2021-01-10 22:35:28'),(3,'Enterprise','enterprise',1,1,'package',70,100,'2021-01-10 22:36:08','2021-01-10 22:36:08'),(4,'Enterprise Pro','enterprise-pro',1,1,'package',150,150,'2021-01-10 22:37:09','2021-01-10 22:37:09'),(5,'Dignissimos ut earum','dignissimos-ut-earum',4,1,'property',0,0,'2021-01-10 22:42:02','2021-01-10 22:49:16'),(6,'Quibusdam sed quos a','quibusdam-sed-quos-a',3,1,'property',0,0,'2021-01-11 14:32:15','2021-01-11 14:38:35'),(7,'Laudantium sint au','laudantium-sint-au',2,1,'property',0,0,'2021-01-11 14:41:48','2021-01-11 14:47:18'),(8,'Directory Will Be A Thing Of The Past.','macy-baker',1,1,'blog',0,0,'2021-01-11 15:54:21','2021-01-11 15:55:31'),(9,'The Most Inspiring Interior Design Of 2021','the-most-inspiring-interior-design-of-2021',1,1,'blog',0,0,'2021-01-11 16:00:21','2021-01-11 16:00:21'),(10,'7 Instagram accounts for interior design enthusiasts','7-instagram-accounts-for-interior-design-enthusiasts',1,1,'blog',0,0,'2021-01-11 16:01:25','2021-01-11 16:01:25'),(11,'About Us','about-us',1,1,'page',0,0,'2021-06-09 00:32:02','2021-06-09 00:32:02'),(12,'Sitemap','sitemap',1,1,'page',0,0,'2021-06-09 00:35:38','2021-06-09 00:35:38'),(13,'Terms And Condition','terms-and-condition',1,1,'page',0,0,'2021-06-09 00:36:02','2021-06-09 00:36:02'),(14,'Privacy Policy','privacy-policy',1,1,'page',0,0,'2021-06-09 00:36:19','2021-06-09 00:36:19'),(15,'Latest News','latest-news',1,1,'page',0,0,'2021-06-09 00:36:34','2021-06-09 00:36:34'),(16,'Blog','blog',1,1,'page',0,0,'2021-06-09 00:37:25','2021-06-09 00:37:25'),(17,'Demo','demo',1,2,'project',0,0,'2021-10-25 08:24:15','2021-10-25 08:24:15');
/*!40000 ALTER TABLE `terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `terms_user`
--

DROP TABLE IF EXISTS `terms_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `terms_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `terms_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `terms_user_terms_id_foreign` (`terms_id`),
  KEY `terms_user_user_id_foreign` (`user_id`),
  CONSTRAINT `terms_user_terms_id_foreign` FOREIGN KEY (`terms_id`) REFERENCES `terms` (`id`) ON DELETE CASCADE,
  CONSTRAINT `terms_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `terms_user`
--

LOCK TABLES `terms_user` WRITE;
/*!40000 ALTER TABLE `terms_user` DISABLE KEYS */;
INSERT INTO `terms_user` (`id`, `terms_id`, `user_id`, `created_at`, `updated_at`) VALUES (1,5,4,'2021-01-10 23:26:55','2021-01-10 23:26:55');
/*!40000 ALTER TABLE `terms_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `term_id` bigint(20) unsigned NOT NULL,
  `payment_method` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `credits` int(11) NOT NULL DEFAULT 0,
  `amount` double DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transactions_user_id_foreign` (`user_id`),
  KEY `transactions_term_id_foreign` (`term_id`),
  CONSTRAINT `transactions_term_id_foreign` FOREIGN KEY (`term_id`) REFERENCES `terms` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_meta`
--

DROP TABLE IF EXISTS `user_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'preview',
  `content` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_meta_user_id_foreign` (`user_id`),
  CONSTRAINT `user_meta_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_meta`
--

LOCK TABLES `user_meta` WRITE;
/*!40000 ALTER TABLE `user_meta` DISABLE KEYS */;
INSERT INTO `user_meta` (`id`, `user_id`, `type`, `content`, `created_at`, `updated_at`) VALUES (1,2,'credit','30','2021-01-10 21:49:27','2021-01-10 22:18:05'),(2,2,'content','{\"address\":\"Kirtipur, Naogaon\",\"phone\":\"0434610979\",\"description\":\"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\",\"facebook\":\"#\",\"twitter\":\"#\",\"youtube\":\"#\",\"pinterest\":\"#\",\"linkedin\":\"#\",\"instagram\":\"#\",\"whatsapp\":\"0434610979\",\"service_area\":\"Savar, Bonani, uttara\",\"tax_number\":\"49345345345\",\"license\":\"983423423423423\"}','2021-01-10 21:49:27','2021-06-09 00:30:20'),(3,3,'credit','0','2021-01-10 22:20:24','2021-01-10 22:21:20'),(4,3,'content','{\"address\":\"Dhaka Savar\",\"phone\":\"0434610979\",\"description\":\"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\",\"facebook\":\"#\",\"twitter\":\"#\",\"youtube\":\"#\",\"pinterest\":\"#\",\"linkedin\":\"#\",\"instagram\":\"#\",\"whatsapp\":\"0434610979\",\"service_area\":\"Dhaka, Rajshahi, Khulna\",\"tax_number\":\"139324324234\",\"license\":\"243324324246786\"}','2021-01-10 22:20:24','2021-06-09 00:29:44'),(5,4,'credit',NULL,'2021-01-10 22:23:44','2021-01-10 22:23:44'),(6,4,'content','{\"address\":\"Agrabad, Chittagong\",\"phone\":\"0434610979\",\"description\":\"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\",\"facebook\":\"#\",\"twitter\":\"#\",\"youtube\":\"#\",\"pinterest\":\"#\",\"linkedin\":\"#\",\"instagram\":\"#\",\"whatsapp\":\"0434610979\",\"service_area\":\"Dhaka, Agrabad, Naogaon\",\"tax_number\":\"404343248979\",\"license\":\"144354367687684\"}','2021-01-10 22:23:44','2021-06-09 00:29:06'),(7,5,'credit','0','2021-06-09 00:57:44','2021-06-09 00:57:44'),(8,5,'content','{\"address\":null,\"phone\":null,\"description\":null,\"facebook\":null,\"twitter\":null,\"youtube\":null,\"pinterest\":null,\"linkedin\":null,\"instagram\":null,\"whatsapp\":null,\"service_area\":null,\"tax_number\":null,\"license\":null}','2021-06-09 00:57:44','2021-06-09 00:57:44'),(9,6,'credit','0','2021-09-12 17:11:38','2021-09-12 17:11:38'),(10,6,'content','{\"address\":null,\"phone\":null,\"description\":null,\"facebook\":null,\"twitter\":null,\"youtube\":null,\"pinterest\":null,\"linkedin\":null,\"instagram\":null,\"whatsapp\":null,\"service_area\":null,\"tax_number\":null,\"license\":null}','2021-09-12 17:11:38','2021-09-12 17:11:38');
/*!40000 ALTER TABLE `user_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `credits` double NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 1,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `role_id`, `avatar`, `credits`, `status`, `name`, `slug`, `email`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `remember_token`, `created_at`, `updated_at`) VALUES (1,1,'https://ui-avatars.com/api/?size=50&background=random&name=Admin',0,1,'Admin','admin','admin@admin.com',NULL,'$2y$10$frSxCgpmTa5HXhZfSSk3YeLRW5Soni3tYkoTWBXRoUV5F4JAnBCa.',NULL,NULL,'yQa7tXQEHWP9QMaf12IDLKU9ovvGYXuAOLA0EqG4BgmiurIwqD1da5VrV9tN','2021-06-09 00:19:31','2021-06-09 00:19:31'),(2,2,'http://realestate.avanteca.com.bd/uploads/21/01/10012116102993185ffb37b69d617.webp',0,1,'Dane Reese','dane-reese','sicequb@wonderit.com.au',NULL,'$2y$10$JJTnkLXAbvjksd5ZnEO5N.8FEYKxQg81rP7v5k/QWWr/3jEzcvMBG',NULL,NULL,NULL,'2021-01-10 21:49:27','2021-06-09 00:30:20'),(3,2,'http://realestate.avanteca.com.bd/uploads/21/01/10012116102975505ffb30ce8a3aa.webp',0,1,'Blythe Dorsey','blythe-dorsey','gaqoq@wonderit.com.au',NULL,'$2y$10$rw9l8G6oKZRFGzBt0FwBN..P1JYNTda0ElNy0c7PfYXxvhN55nZc.',NULL,NULL,NULL,'2021-01-10 22:20:24','2021-06-09 00:29:44'),(4,2,'http://realestate.avanteca.com.bd/uploads/21/01/10012116102994195ffb381b1b55c.webp',0,1,'Orlando Whitf','orlando-whitf','mahi@wonderit.com.au',NULL,'$2y$10$08PwkxcrxxyNk6gl5VtruewBHiBOmaPtJw8cUNrQOBABmU9Ercsuq',NULL,NULL,NULL,'2021-01-10 22:23:44','2021-06-09 00:29:06'),(5,2,'https://ui-avatars.com/api/?size=250&background=random&name=Mohsin Sheikh',0,1,'Mohsin Sheikh','mohsin-sheikh','mohsin235071@gmail.com',NULL,'$2y$10$kzn5S/L7ZlbvAJmy6EZ6d.hgB9Or90twJ7AqwkChrmiDBPdOOT.yi',NULL,NULL,'A7Epi5uiAwyOWsd1tSNfIu949rbH3Laha63qT5a9EL1Rqg4CHs985r8hT1su','2021-06-09 00:57:44','2021-06-09 00:57:44'),(6,2,'https://ui-avatars.com/api/?size=250&background=random&name=kiron',0,1,'kiron','kiron','kironnibir046@gmail.com',NULL,'$2y$10$mbf1jFh8LHDIwonHZ5o5KOaW.ITPuAtaFxkLRKCyveBSJB6zVKAei',NULL,NULL,NULL,'2021-09-12 17:11:38','2021-09-12 17:11:38');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'avanteca_reales'
--

--
-- Dumping routines for database 'avanteca_reales'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-11  4:02:07
